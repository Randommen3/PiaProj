import express from 'express'
import multer from 'multer';
import { KorisnikController } from '../controllers/Korisnik.controller';

const korRouter = express.Router()

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

korRouter.route("/register").post(upload.single('image'),(req,res)=> new KorisnikController().register(req,res))
korRouter.route("/azurirajSliku").post(upload.single('image'),(req,res)=> new KorisnikController().azurirajSliku(req,res))

korRouter.route("/login").post( (req,res)=> new KorisnikController().login(req,res))

korRouter.route("/loginAdmin").post( (req,res)=> new KorisnikController().loginAdmin(req,res))

korRouter.route("/promenaLozinkeStarom").post( (req,res)=> new KorisnikController().promenaLozinkeStarom(req,res))

korRouter.route("/sviKor").get( (req,res)=> new KorisnikController().sviKor(req,res))
korRouter.route("/sviGosti").get( (req,res)=> new KorisnikController().sviGosti(req,res))
korRouter.route("/sviKonobari").get( (req,res)=> new KorisnikController().sviKonobari(req,res))

korRouter.route("/dohvatiBrojGostiju").get( (req,res)=> new KorisnikController().dohvatiBrojGostiju(req,res))

korRouter.route("/azurirajInfo").post( (req,res)=> new KorisnikController().azurirajInfo(req,res))
korRouter.route("/azurirajInfo2").post( (req,res)=> new KorisnikController().azurirajInfo2(req,res))

korRouter.route("/aktivirajKorisnika").post( (req,res)=> new KorisnikController().aktivirajKorisnika(req,res))
korRouter.route("/deaktivirajKorisnika").post( (req,res)=> new KorisnikController().deaktivirajKorisnika(req,res))
korRouter.route("/odobriKorisnika").post( (req,res)=> new KorisnikController().odobriKorisnika(req,res))
korRouter.route("/odbijKorisnika").post( (req,res)=> new KorisnikController().odbijKorisnika(req,res))

korRouter.route("/dodajKonobara").post((req,res)=> new KorisnikController().dodajKonobara(req,res))
korRouter.route("/uvecajKorisnikuBlokiran").post((req,res)=> new KorisnikController().uvecajKorisnikuBlokiran(req,res))







export default korRouter;
