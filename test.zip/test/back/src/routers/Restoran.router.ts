import express from 'express'
// import multer from 'multer';
import { RestoranController } from '../controllers/Restoran.controller';

const resRouter = express.Router()

// const storage = multer.memoryStorage();
// const upload = multer({ storage: storage });

// korRouter.route("/register").post(upload.single('image'),(req,res)=> new KorisnikController().register(req,res))

resRouter.route("/dohvatiSveRestorane").get( (req,res)=> new RestoranController().dohvatiSveRestorane(req,res))

resRouter.route("/dohvatiBrojRestorana").get( (req,res)=> new RestoranController().dohvatiBrojRestorana(req,res))

resRouter.route("/dodajRadneSate").post( (req,res)=> new RestoranController().dodajRadneSate(req,res))

resRouter.route("/dohvatiRestoran").post( (req,res)=> new RestoranController().dohvatiRestoran(req,res))

resRouter.route("/dohvatiFiltrovaneRestorane").post( (req,res)=> new RestoranController().dohvatiFiltrovaneRestorane(req,res))


resRouter.route("/dodajRestoran").post( (req,res)=> new RestoranController().dodajRestoran(req,res))

// korRouter.route("/login").post( (req,res)=> new KorisnikController().login(req,res))

// korRouter.route("/loginAdmin").post( (req,res)=> new KorisnikController().loginAdmin(req,res))

// korRouter.route("/promenaLozinkeStarom").post( (req,res)=> new KorisnikController().promenaLozinkeStarom(req,res))

// korRouter.route("/sviKor").get( (req,res)=> new KorisnikController().sviKor(req,res))


export default resRouter;
