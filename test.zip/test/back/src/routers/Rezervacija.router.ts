import express from 'express'
import { RezervacijaController } from '../controllers/Rezervacija.controller';

const rezRouter = express.Router()

// resRouter.route("/dohvatiSveRestorane").get( (req,res)=> new RestoranController().dohvatiSveRestorane(req,res))

// resRouter.route("/dohvatiBrojRestorana").get( (req,res)=> new RestoranController().dohvatiBrojRestorana(req,res))

// resRouter.route("/dodajRadneSate").post( (req,res)=> new RestoranController().dodajRadneSate(req,res))

// resRouter.route("/dohvatiRestoran").post( (req,res)=> new RestoranController().dohvatiRestoran(req,res))

// resRouter.route("/dohvatiFiltrovaneRestorane").post( (req,res)=> new RestoranController().dohvatiFiltrovaneRestorane(req,res))


// resRouter.route("/dodajRestoran").post( (req,res)=> new RestoranController().dodajRestoran(req,res))

rezRouter.route("/dodajRez").post( (req,res)=> new RezervacijaController().dodajRez(req,res))
rezRouter.route("/aktuelneRezervacijeZaKorisnika").post( (req,res)=> new RezervacijaController().aktuelneRezervacijeZaKorisnika(req,res))
rezRouter.route("/istekleRezervacijeZaKorisnika").post( (req,res)=> new RezervacijaController().istekleRezervacijeZaKorisnika(req,res))
rezRouter.route("/otkaziRezervaciju").post( (req,res)=> new RezervacijaController().otkaziRezervaciju(req,res))
rezRouter.route("/dohvatiNeobradjeneRezervacijeZaRestoran").post( (req,res)=> new RezervacijaController().dohvatiNeobradjeneRezervacijeZaRestoran(req,res))

rezRouter.route("/prihvatiRez").post( (req,res)=> new RezervacijaController().prihvatiRez(req,res))
rezRouter.route("/odbijRez").post( (req,res)=> new RezervacijaController().odbijRez(req,res))

rezRouter.route("/rezervacijeKojeOcekujeKonobar").post( (req,res)=> new RezervacijaController().rezervacijeKojeOcekujeKonobar(req,res))
rezRouter.route("/gostNijeDosao").post( (req,res)=> new RezervacijaController().gostNijeDosao(req,res))
rezRouter.route("/gostDosao").post( (req,res)=> new RezervacijaController().gostDosao(req,res))
rezRouter.route("/produziRez").post( (req,res)=> new RezervacijaController().produziRez(req,res))
rezRouter.route("/dohvatiTrenutnoUsluzavaneRezervacije").post( (req,res)=> new RezervacijaController().dohvatiTrenutnoUsluzavaneRezervacije(req,res))






rezRouter.route("/testRez").get( (req,res)=> new RezervacijaController().testRez(req,res))






export default rezRouter;
