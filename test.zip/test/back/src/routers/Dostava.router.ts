import express from 'express'
import { DostavaController } from '../controllers/Dostava.controller';

const dosRouter = express.Router()

dosRouter.route("/dodajDostavu").post( (req,res)=> new DostavaController().dodajDostavu(req,res))

dosRouter.route("/dohvatiAktuelneDostave").post( (req,res)=> new DostavaController().dohvatiAktuelneDostave(req,res))

// rezRouter.route("/dodajRez").post( (req,res)=> new RezervacijaController().dodajRez(req,res))

export default dosRouter;
