import express from 'express'
import Restoran from '../models/Restoran';

export class RestoranController{

    dohvatiFiltrovaneRestorane = (req: express.Request, res: express.Response)=>{

        const { naziv, tip, adresa } = req.body;

        console.log("naziv "+naziv+" tip "+tip+" adresa "+adresa)

        const query:any = {};

        if (naziv) {
        query.naziv = { $regex: naziv, $options: 'i' }; // 'i' for case-insensitive
        }

        if (tip) {
        query.tip = { $regex: tip, $options: 'i' };
        }

        if (adresa) {
        query.adresa = { $regex: adresa, $options: 'i' };
        }
        console.log('filter:')
        console.log(query)

        Restoran.find(query).then(
        data => {
            res.json(data);
        }
        ).catch(
        err => {
            console.error('Error fetching restaurants', err);
            res.status(500).send({ message: 'Error fetching restaurants' });
        })

        // res.json({message:"ok"})
    }


    dohvatiSveRestorane = (req: express.Request, res: express.Response)=>{

        Restoran.find({}).then(
            data=>{
                res.json(data)
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error catching users' });
        });
    }

    dohvatiBrojRestorana = (req: express.Request, res: express.Response)=>{
        Restoran.countDocuments({}).then(
            data=>{
                {
                    console.log('br rest '+data)
                    res.json(data)
                }
            }
        ).catch((err) => {
            console.error('Greska u brojenju restorana',err)
            return res.json(null)
        });
    }

    dodajRadneSate = (req: express.Request, res: express.Response)=>{
        let naziv=req.body.naziv
        let radnoVremeOd=req.body.radnoVremeOd
        let radnoVremeDo=req.body.radnoVremeDo

        Restoran.updateOne({naziv:naziv},{radnoVremeOd:radnoVremeOd,radnoVremeDo:radnoVremeDo}).then(
            data=>{
                res.json({message:'ok'})
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error catching users' });
        });
    }

    dohvatiRestoran = (req: express.Request, res: express.Response)=>{
        let naziv=req.body.naziv
        Restoran.findOne({naziv:naziv}).then(data=>{
            res.json(data)
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error catching users' });
        });
    }

    // async dohvatiRestoranInterno(naziv: String) {
    //     Restoran.findOne({naziv:naziv}).then(data=>{
    //         console.log(data)
    //         return data
    //         }
    //     ).catch((err) => {
    //         console.log(err);
    //     });
    // }

    dodajRestoran = (req: express.Request, res: express.Response)=>{
//         Приликом уноса новог ресторана, уносе се назив
// ресторана, тип ресторана, адреса, кратак опис ресторана и контакт особа за ресторан.
        let r=req.body.restoran
        console.log(r)

        let noviRes = {
            naziv: r.naziv,
            adresa: r.adresa,
            tip:r.tip,
            opis: r.opis,
            telefon:r.telefon,
            brStolova:r.brStolova,
            osobaPoStolu:r.osobaPoStolu,
            radnoVremeOd:r.radnoVremeOd,
            radnoVremeDo:r.radnoVremeDo,
            komentari:r.komentari,
            jela:r.jela
        };
        console.log('dodavanje resotrana '+ noviRes.naziv)
        new Restoran(noviRes).save().then(
            data=>{
                console.log(data)
                res.json({message:'ok'})
            }
        )


    }


    


}
