import express from 'express'
import { Request, Response } from 'express';
import Korisnik from '../models/Korisnik';
import * as fs from 'fs';
import * as path from 'path';
import bcrypt, { hash } from 'bcrypt';






export class KorisnikController{
    
    login = (req: express.Request, res: express.Response)=>{
        let korisnik=req.body.korisnik
        let lozinka = korisnik.lozinka;
        Korisnik.findOne({ kor_ime: korisnik.kor_ime }).then((user) => {
            if (!user || !user.lozinka) {
                return res.status(401).json({ message: 'Invalid username or password' });
            }
            
            bcrypt.compare(lozinka, user.lozinka, (err, isMatch) => {
                if (err) {
                    return res.status(500).json({ message: 'Error comparing passwords' });
                }

                if (isMatch) {
                    if(user.tip=='admin'){
                        res.json(null);
                    }else{
                    res.json(user);

                    }
                } else {
                    res.json(null);
                }
            });
        }).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error logging in' });
        });           
    }

    loginAdmin = (req: express.Request, res: express.Response)=>{
        let korisnik=req.body.korisnik
        let lozinka = korisnik.lozinka;
        
        Korisnik.findOne({ kor_ime: korisnik.kor_ime,tip:"admin" }).then((user) => {
            if (!user || !user.lozinka) {
                return res.status(401).json({ message: 'Invalid username or password' });
            }
            
            bcrypt.compare(lozinka, user.lozinka, (err, isMatch) => {
                if (err) {
                    return res.status(500).json({ message: 'Error comparing passwords' });
                }
                if (isMatch) {
                    res.json(user);
                } else {
                    res.status(401).json({ message: 'Invalid username or password' });
                }
            });
        }).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error logging in' });
        });    
    }

    register = (req: express.Request, res: express.Response)=>{
        console.log('reg')
        console.log(req.body)
        const korisnikData = JSON.parse(req.body.korisnik);
        console.log(korisnikData)
        let kor_ime=korisnikData.kor_ime
        let lozinka=korisnikData.lozinka
        console.log("sace fajl")
        
        let slika = req.file?.buffer.toString('base64');

        if (!kor_ime || !lozinka) {
            return res.status(400).send({ message: 'Please provide all required fields.' });
        }

        if(!slika){
            let defImagePath=path.join(__dirname,"..","..","src","images","default.jpg")
            slika = fs.readFileSync(defImagePath).toString('base64')
            console.log('default pic\n')
        }

        bcrypt.hash(lozinka, 10, (err, hashedPassword) => {
            if (err) {
                return res.status(500).json({ message: 'Error hashing password' });
            }

            let noviKor = {
                kor_ime: kor_ime,
                lozinka: hashedPassword,
                tip:"gost",
                slika: slika,
                ime:korisnikData.ime,
                prezime:korisnikData.prezime,
                pol:korisnikData.pol,
                adresa:korisnikData.adresa,
                kontakt:korisnikData.kontakt,
                pitanje:korisnikData.pitanje,
                odgovor:korisnikData.odgovor,
                brojKartice:korisnikData.brojKartice,
                imejl:korisnikData.imejl,
                blokiran:0,
                deaktiviran:0,
                odobren:0
            };
            console.log(lozinka)
            
            console.log(noviKor.lozinka)

            new Korisnik(noviKor).save().then(
                ok => {
                    console.log("dodat " + kor_ime);
                    res.json({ message: "ok" });
                }
            ).catch(err => {
                console.log(err);
                res.status(500).json({ message: 'Error saving user' });
            });
        });



        // let noviKor={
        //     kor_ime:kor_ime,
        //     lozinka:lozinka,
        //     slika:slika
        // }
        // new Korisnik(noviKor).save().then(
        //     ok=>{
        //         console.log("dodat "+kor_ime)
        //     res.json({message:"ok"})}
        // ).catch(err=>{
        //     console.log(err)
        // })
    }


    promenaLozinkeStarom = (req: express.Request, res: express.Response)=>{
        let korisnik=req.body.korisnik
        let lozinka = korisnik.lozinka;
        let novaLozinka= req.body.novaLozinka
        console.log("lozinka "+korisnik.kor_ime)
        console.log(novaLozinka)
        Korisnik.findOne({ kor_ime: korisnik.kor_ime }).then((user) => {
            if (!user || !user.lozinka) {
                return res.status(401).json({ message: 'Invalid username or password' });
            }
            
            bcrypt.compare(lozinka, user.lozinka, (err, isMatch) => {
                if (err) {
                    return res.status(500).json({ message: 'Error comparing passwords' });
                }

                if (isMatch) {
                    bcrypt.hash(novaLozinka, 10, (err, novaHashLozinka) => {
                        if (err) {
                            return res.status(500).json({ message: 'Error hashing password' });
                        }

                        Korisnik.updateOne({kor_ime:korisnik.kor_ime},{lozinka:novaHashLozinka}).then(
                            data=>{
                                console.log(data)
                                res.json({message:'ok'})
                            }
                        )

                    })
                } else {
                    res.json(null);
                }
            });
        }).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error logging in' });
        });           
    }

    sviKor = (req: express.Request, res: express.Response)=>{
        Korisnik.find({}).then(
            data=>{
                res.json(data)
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error catching users' });
        });
    }

    sviKonobari = (req: express.Request, res: express.Response)=>{
        Korisnik.find({tip:'konobar'}).then(
            data=>{
                res.json(data)
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error catching users' });
        });
    }

    sviGosti = (req: express.Request, res: express.Response)=>{
        Korisnik.find({tip:'gost'}).then(
            data=>{
                res.json(data)
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error catching users' });
        });
    }
    
    dohvatiBrojGostiju = (req: express.Request, res: express.Response)=>{
        Korisnik.countDocuments({tip:"gost"}).then(
            data=>{
                {
                    console.log('br gost '+data)
                    res.json(data)
                }
            }
        ).catch((err) => {
            console.error('Greska u brojenju gostiju',err)
            return res.json(null)
        });
    }

    dohvatiSigPitanje = (req: express.Request, res: express.Response)=>{
        let korisnik=req.body.korisnik
        let lozinka = korisnik.lozinka;
        
        Korisnik.findOne({ kor_ime: korisnik.kor_ime,tip:"admin" }).then((user) => {
            if (!user || !user.lozinka) {
                return res.status(401).json({ message: 'Invalid username or password' });
            }
            
            bcrypt.compare(lozinka, user.lozinka, (err, isMatch) => {
                if (err) {
                    return res.status(500).json({ message: 'Error comparing passwords' });
                }
                if (isMatch) {
                    res.json(user);
                } else {
                    res.status(401).json({ message: 'Invalid username or password' });
                }
            });
        }).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error logging in' });
        });    
    }

    azurirajInfo = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime
        let ime=req.body.ime    
        let prezime=req.body.prezime
        let imejl=req.body.imejl
        let kontakt=req.body.kontakt
        let brojKartice=req.body.brojKartice


        Korisnik.updateOne({kor_ime:kor_ime},{ime:ime,prezime:prezime,imejl:imejl,kontakt:kontakt,brojKartice:brojKartice}).then(
            data=>{
                console.log('azuriran korisnik'+kor_ime+'\n')
                console.log(data)
                res.json({message:'ok'})
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error logging in' });
        }); 
    }

    azurirajInfo2 = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime
        let ime=req.body.ime    
        let prezime=req.body.prezime
        let imejl=req.body.imejl
        let kontakt=req.body.kontakt


        Korisnik.updateOne({kor_ime:kor_ime},{ime:ime,prezime:prezime,imejl:imejl,kontakt:kontakt}).then(
            data=>{
                console.log('azuriran korisnik'+kor_ime+'\n')
                console.log(data)
                res.json({message:'ok'})
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error logging in' });
        }); 
    }


    azurirajSliku = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime

        let slika = req.file?.buffer.toString('base64');



        Korisnik.updateOne({kor_ime:kor_ime},{slika:slika}).then(
            data=>{
                console.log('azuriran slika korisnika '+kor_ime+'\n'+data)
                res.json({message:'ok'})
            }
        ).catch((err) => {
            console.log(err);
            res.status(500).json({ message: 'Error logging in' });
        }); 
    }

    deaktivirajKorisnika = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime

        Korisnik.updateOne({kor_ime:kor_ime},{deaktiviran:1}).then(
            data=>{
                console.log('deaktiviranje '+kor_ime)
                console.log(data)
                res.json({message:'ok'})
            }
        )
    }

    aktivirajKorisnika = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime

        Korisnik.updateOne({kor_ime:kor_ime},{deaktiviran:0}).then(
            data=>{
                console.log('aktiviranje '+kor_ime)
                console.log(data)
                res.json({message:'ok'})
            }
        )
    }

    odobriKorisnika = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime

        Korisnik.updateOne({kor_ime:kor_ime},{odobren:1}).then(
            data=>{
                console.log('odobri '+kor_ime)
                console.log(data)
                res.json({message:'ok'})
            }
        )
    }

    odbijKorisnika = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime

        Korisnik.updateOne({kor_ime:kor_ime},{odobren:2}).then(
            data=>{
                console.log('odbij '+kor_ime)
                console.log(data)
                res.json({message:'ok'})
            }
        )
    }

    dodajKonobara = (req: express.Request, res: express.Response)=>{
        console.log('dodavanje konobara')
        const k=req.body
        // console.log(k)
        // console.log(req.body.nazivRestorana)

        let kor_ime=k.kor_ime
        let lozinka=k.lozinka
        console.log(k)
        // console.log(lozinka+"  "+kor_ime)
        let defImagePath=path.join(__dirname,"..","..","src","images","default.jpg")
        let slika = fs.readFileSync(defImagePath).toString('base64')
       

        bcrypt.hash(lozinka, 10, (err, hashedPassword) => {
            if (err) {
                return res.status(500).json({ message: 'Error hashing password' });
            }

            let noviKor = {
                kor_ime: kor_ime,
                lozinka: hashedPassword,
                tip:"konobar",
                slika: slika,
                ime:k.ime,
                prezime:k.prezime,
                pol:k.pol,
                adresa:k.adresa,
                kontakt:k.kontakt,
                pitanje:k.pitanje,
                odgovor:k.odgovor,
                imejl:k.imejl,
                blokiran:0,
                deaktiviran:0,
                odobren:1,
                radiU:k.radiU
            };
            console.log(lozinka)
            console.log(noviKor.lozinka)

            new Korisnik(noviKor).save().then(
                ok => {
                    console.log("dodat konobar " + kor_ime);
                    res.json({ message: "ok" });
                }
            ).catch(err => {
                console.log(err);
                res.status(500).json({ message: 'Error saving user' });
            });
        });
    }

    uvecajKorisnikuBlokiran = (req: express.Request, res: express.Response)=>{
        let kor_ime = req.body.kor_ime;

        Korisnik.updateOne(
            { kor_ime: kor_ime },
            { $inc: { blokiran: 1 } }
        )
        .then(data => {
            console.log('Korisnik updated', data);
            res.json({ message: 'ok' });
        })
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error updating user' });
        }); 
    }
    
}
