import express from 'express'
import Dostava from '../models/Dostava'



export class DostavaController{

   dodajDostavu = (req: express.Request, res: express.Response)=>{
    console.log(req.body)
    
    new Dostava(req.body).save().then(
        data=>{
            res.json({message:'ok'})
        }
    ).catch((err) => {
        console.log(err);
        res.status(500).json({ message: 'Error saving delivery' });
    });  
   }

   dohvatiAktuelneDostave = (req: express.Request, res: express.Response)=>{
    Dostava.find({kor_ime:req.body.kor_ime,stanje:1}).then(
        data=>{
            console.log(data)
        }
    ).catch((err) => {
        console.log(err);
        res.status(500).json({ message: 'Error fetching deliveries' });
    });  
   }
                    
}
