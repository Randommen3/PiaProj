import express from 'express'
import Rezervacija from '../models/Rezervacija'
import mongoose from 'mongoose'
import moment from 'moment'
import  { RestoranController } from './Restoran.controller'
import Restoran from '../models/Restoran'

export class RezervacijaController{


//     				            pojavio		prihvacen	    otkazao



// rez poslata na odobrenje	    0		    false		    false

// rez se odbila uz komentar	0	    	true	    	false  + komentar:"nesto"

// rez se prihvatila		    0	    	true	    	false

//nije se prihvatila i otkazo0  0           false            true

// prihvatila se i otkazao je	0	    	true	    	true

// prihvatila se a nije dosao	1	    	true	    	false

// prihvatila se i dosao		2	    	true	    	false
// a mogao sam lepo jedan int, jebomesvetipetar





    // isReservationWithinWorkingHours(reservationDate: Date, workingFrom: string, workingTill: string): boolean {
    //     const reservationTime = moment(reservationDate).format('HH:mm');
    //     return moment(reservationTime, 'HH:mm').isBetween(moment(workingFrom, 'HH:mm'), moment(workingTill, 'HH:mm'), null, '[]');
    // }

    dodajRez = (req: express.Request, res: express.Response)=>{
        console.log(new Date())
        let rez=req.body.rez
        let maxBrojStolovaRestorana=req.body.maxBrojStolovaRestorana
        // console.log(rez)
        console.log(maxBrojStolovaRestorana)
        

        let restoran=rez.restoran
        let datum = rez.datum
        let brStolova = rez.brStolova
        let startDate = new Date(datum)
        let endDate= new Date(startDate.getTime() + 3 * 60 * 60 * 1000);

        // let r= await new RestoranController().dohvatiRestoranInterno(rez.restoran)
        // console.log('sace r')
        // console.log(r)
        // if(r!=null){
        //     res.json({message:'ne mogu da pronadjem'})
        //     return
        // }
        

        Rezervacija.find({
            restoran: restoran,
            $or: [
                { datum: { $lte: endDate, $gte: startDate } },
                { datum: { $gte: startDate, $lte: endDate } },
                { oslobadjanje: { $gt: startDate, $lte: endDate } }
            ]
        }).then(reservations => {
            console.log(reservations.length)
            const reservedTables = reservations.reduce((acc, res) => acc + (res.brStolova??0), 0);
            const availableTables = maxBrojStolovaRestorana - reservedTables; // Assume you know the total number of tables in the restaurant
            console.log(" avail: "+availableTables+",  nama treba"+brStolova)
            if (availableTables >= brStolova) {

                let novaRez={
                    kor_ime:rez.kor_ime,
                    restoran:rez.restoran,
                    datum:startDate,
                    oslobadjanje:endDate,
                    brOsoba:rez.brOsoba,
                    brStolova:rez.brStolova,
                    dodatniZahtevi:rez.dodatniZahtevi,
                    pojavio:0,
                    ocenio:false,
                    produzio:false,
                    konobar:"",
                    prihvacen:false,
                    otkazao:false
                }
                console.log('dodavanje rezervacije za '+novaRez.restoran+ "  "+novaRez.datum)

                new Rezervacija(novaRez).save().then(
                    data=>{
                        console.log(data)
                        res.json({message:'ok'})
                    }
                )


                // res.json({ available: true, message: 'Tables are available for the given time period.' });
            } else {
                res.json({  message: 'Ne moze se rezervisati' });
            }
        })
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error checking table availability' });
        });
    }

    aktuelneRezervacijeZaKorisnika = (req: express.Request, res: express.Response)=>{
        console.log(req.body.kor_ime)

        Rezervacija.find({kor_ime:req.body.kor_ime,prihvacen:true,otkazao:false,pojavio:0,
            komentar: { $ne: '' }}).then(
            data=>{
                console.log("aktuelneRezervacijeZaKorisnika")
                console.log(data)
                res.json(data)
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }

    istekleRezervacijeZaKorisnika = (req: express.Request, res: express.Response)=>{
        console.log(req.body.kor_ime)

        Rezervacija.find({kor_ime:req.body.kor_ime,prihvacen:true,otkazao:false,pojavio:1}).then(
            data=>{
                console.log("istekleRezervacijeZaKorisnika")
                console.log(data)
                res.json(data)
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }
    otkaziRezervaciju = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime
        let restoran=req.body.restoran
        let datum=req.body.datum
        console.log(kor_ime)
        console.log(restoran)
        console.log(datum)
        datum=new Date(datum)
        console.log(datum)

        Rezervacija.updateOne({kor_ime:kor_ime,restoran:restoran,datum:datum},{otkazao:true}).then(
            data=>{
                console.log("rez za tokaz?")
                console.log(data)
                res.json({message:'ok'})
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }

    dohvatiNeobradjeneRezervacijeZaRestoran = (req: express.Request, res: express.Response)=>{
        let restoran=req.body.restoran
        console.log(restoran+" za dohvatiNeobradjeneRezervacijeZaRestoran")
        const currentDate = new Date();

        Rezervacija.find({
            restoran: restoran,
            prihvacen: false,
            komentar: { $ne: '' },
            datum: { $gt: currentDate } // Field 'datum' is in the future
        }).then(
            data=>{
                console.log(restoran+", ovoliko ima za restoran:"+data.length)
                res.json(data)
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }

    testRez = (req: express.Request, res: express.Response)=>{

        Rezervacija.updateMany({},{komentarOtkaza:''}).then(
            data=>{
                console.log(data)
                res.json(data)
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }
    prihvatiRez = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime
        let restoran=req.body.restoran
        let datum=req.body.datum
        let konobar=req.body.konobar

        Rezervacija.updateOne({kor_ime:kor_ime,restoran:restoran,datum:datum},{prihvacen:true,konobar:konobar}).then(
            data=>{
                console.log("rez prihvacena: ")
                res.json({message:'ok'})
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }

    odbijRez = (req: express.Request, res: express.Response)=>{
        let kor_ime=req.body.kor_ime
        let restoran=req.body.restoran
        let datum=req.body.datum
        let komentarOtkaza = req.body.komentarOtkaza

        Rezervacija.updateOne({kor_ime:kor_ime,restoran:restoran,datum:datum},{prihvacen:true,komentarOtkaza:komentarOtkaza}).then(
            data=>{
                console.log("rez odbijena:")
                res.json({message:'ok'})
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }

    rezervacijeKojeOcekujeKonobar = (req: express.Request, res: express.Response)=>{
        let konobar=req.body.konobar

        Rezervacija.find({
            konobar:konobar,
            pojavio:0,
            otkazao:false
        }).then(
            data=>{
                console.log(konobar+", ovoliko ima koje ocekuje:"+data.length)
                res.json(data)
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }

    gostNijeDosao = (req: express.Request, res: express.Response)=>{
        
        let kor_ime=req.body.kor_ime
        let restoran=req.body.restoran
        let datum=req.body.datum

        Rezervacija.updateOne({kor_ime:kor_ime,restoran:restoran,datum:datum},{pojavio:2,prihvacen:false}).then(
            data=>{
                console.log(`Potvrdjeno da ${kor_ime} nije dosao`)
                console.log(data)
                res.json({message:'ok'})
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });

    }

    gostDosao = (req: express.Request, res: express.Response)=>{
        
        let kor_ime=req.body.kor_ime
        let restoran=req.body.restoran
        let datum=req.body.datum

        Rezervacija.updateOne({kor_ime:kor_ime,restoran:restoran,datum:datum},{pojavio:1}).then(
            data=>{
                console.log(`Potvrdjeno da je ${kor_ime}  dosao`)
                console.log(data)
                res.json({message:'ok'})
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });

    }
    produziRez = (req: express.Request, res: express.Response)=>{
        
        let kor_ime=req.body.kor_ime
        let restoran=req.body.restoran
        let datum=req.body.datum

        let newOslobadjanje = new Date(datum);
        console.log(newOslobadjanje)
        newOslobadjanje.setHours(newOslobadjanje.getHours() + 4);
        console.log(newOslobadjanje)

        Rezervacija.updateOne({kor_ime:kor_ime,restoran:restoran,datum:datum},{produzio:true,oslobadjanje:newOslobadjanje}).then(
            data=>{

                console.log(data)
                res.json({message:'ok'})
            }
        )
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });

    }

    dohvatiTrenutnoUsluzavaneRezervacije = (req: express.Request, res: express.Response)=>{

        let konobar = req.body.konobar;
        let currentTime = new Date();

        Rezervacija.find({ pojavio: 1, konobar: konobar, oslobadjanje: { $gt: currentTime } })
        .then(data => {
            console.log(`Ima ${data.length} trenutno usluzavanih rezervacija`);
            res.json(data);
        })
        .catch(err => {
            console.error('Error ', err);
            res.status(500).send({ message: 'Error fetching reservations' });
        });
    }
}
