import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import multer from 'multer';
import korRouter from './routers/Korisnik.router';
import resRouter from './routers/Restoran.router';
import rezRouter from './routers/Rezervacija.router';
import dosRouter from './routers/Dostava.router';

const app = express();

app.use(cors())
app.use(express.json())
let DatabaseName='proj_PIA_23_34_jul'
mongoose.connect('mongodb://127.0.0.1:27017/'+DatabaseName)
mongoose.connection.once('open',()=>{
    console.log('Povezano sa '+DatabaseName)
})

// let multer = require('multer')

// const storage = multer.memoryStorage();
// const upload = multer({ storage: storage });


const router=express.Router()
router.use('/korisnik',korRouter)
router.use('/restoran',resRouter)
router.use('/rezervacija',rezRouter)
router.use('/dostava',dosRouter)

app.use('/',router)
// app.get('/', (req, res) => res.send('Hello World!'));
app.listen(4000, () => console.log(`Express server running on port 4000`));
