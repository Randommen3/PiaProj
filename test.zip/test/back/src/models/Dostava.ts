import mongoose from "mongoose";
import { jeloSchema } from "./Restoran";
const dostavaSchema = new mongoose.Schema(
    {
        kor_ime:String,
        restoran:String,
        jela:[jeloSchema],
        stanje:Number,
        procena:String,
        vremeOdluke:Date
    }
)

export default mongoose.model('Dostava',dostavaSchema,'dostave')
