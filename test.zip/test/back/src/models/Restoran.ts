import mongoose from 'mongoose';

export const jeloSchema = new mongoose.Schema({
  naziv: String,
  slika: String,
  opis: String,
  cena: Number,
  kolicina: Number,
  sastojci:[String]
});

const komentarSchema = new mongoose.Schema({
  korisnik: String,
  tekst: String,
  ocena: Number,
  datum: Date
});

const restoranSchema = new mongoose.Schema({
  naziv: String,
  adresa: String,
  tip: String,
  opis:String,
  brStolova:Number,
  osobaPoStolu:Number,
  telefon: String,
  radnoVremeOd:String,
  radnoVremeDo:String,
  komentari: [komentarSchema],
  jela: [jeloSchema]
});


export default mongoose.model('Restoran', restoranSchema, 'restorani');
// restoran:
// 	naziv
// 	adresa
// 	tip
// 	telefon
// 	lista komentara
// 	mapa?
// 	jela[]:
// 		naziv:
// 		cena:
// 		sastojci[]

