import mongoose from "mongoose";

const korisnikSchema = new mongoose.Schema(
    {
        kor_ime:String,
        lozinka:String,
        tip:String,
        ime:String,
        prezime:String,
        pol:String,
        adresa:String,
        kontakt:String,
        pitanje:String,
        odgovor:String,
        slika:String,
        brojKartice:String,
        imejl:String,
        blokiran:Number,
        deaktiviran:Number,
        odobren:Number,
        radiU:String
    }
)

export default mongoose.model('KorisnikModel',korisnikSchema,'korisnici')
