import mongoose from "mongoose";

const rezervacijaSchema = new mongoose.Schema(
    {
        kor_ime:String,
        restoran:String,
        datum:Date,
        oslobadjanje:Date,
        brOsoba:Number,
        brStolova:Number,
        dodatniZahtevi:String,
        pojavio:Number,
        ocenio:Boolean,
        produzio:Boolean,
        konobar:String,
        prihvacen:Boolean,
        komentarOtkaza:String,
        otkazao:Boolean
    }
)

export default mongoose.model('RezervacijaModel',rezervacijaSchema,'rezervacije')
