import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeniKonobarComponent } from './meni-konobar.component';

describe('MeniKonobarComponent', () => {
  let component: MeniKonobarComponent;
  let fixture: ComponentFixture<MeniKonobarComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MeniKonobarComponent]
    });
    fixture = TestBed.createComponent(MeniKonobarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
