import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-meni-konobar',
  templateUrl: './meni-konobar.component.html',
  styleUrls: ['./meni-konobar.component.css']
})
export class MeniKonobarComponent {

  constructor(private router:Router){}

  odjava(){
    // localStorage.clear()
    this.router.navigate([''])
  }
}
