import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-meni-gost',
  templateUrl: './meni-gost.component.html',
  styleUrls: ['./meni-gost.component.css']
})
export class MeniGostComponent {
  constructor(private router:Router){}

  odjava(){
    // localStorage.clear()
    this.router.navigate([''])
  }
}
