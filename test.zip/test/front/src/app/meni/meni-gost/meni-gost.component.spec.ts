import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeniGostComponent } from './meni-gost.component';

describe('MeniGostComponent', () => {
  let component: MeniGostComponent;
  let fixture: ComponentFixture<MeniGostComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MeniGostComponent]
    });
    fixture = TestBed.createComponent(MeniGostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
