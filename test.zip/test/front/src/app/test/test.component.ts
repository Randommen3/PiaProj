import { Component } from '@angular/core';
import { TestService } from '../services/test.service';
import { Korisnik } from '../models/Korisnik';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent {


  private selectedFile: File | null = null;

  constructor( private testS:TestService){}

  regMsg:String=''
  onFileSelected(event:any) {
    this.selectedFile=<File>event.target.files[0]
    if(this.selectedFile==null)
      return
    this.validateImage(this.selectedFile).then(
      isValid=>{
        if(isValid)
          console.log(" validna")
      }
    ).catch(error => {
      if(error==false){
        this.selectedFile=null
      }
      console.log(error);
    });
    console.log("log hoce")
    // if(this.selectedFile==null){
    //   console.log("nije ok")
    //   return
    // }
    // else{
    //   console.log("proslo")
    // }
    // console.log(msg)
    // if(msg!="ok"){
    //   this.regMsg=msg
    //   console.log('Nije ok')
    //   return
    // }
    // console.log(this.selectedFile)
  }

  // validateImage(file: File):Promise<boolean> {
  //   return new Promise ((resolve,reject)=>{
  //     if(file==null)
  //       reject(false)
  //     const img = new Image();
  //     img.src = URL.createObjectURL(file);
  //     this.regMsg=""

  //     img.onload = () => {
  //       let t=0
  //       if (img.width < 100 || img.height < 100 || img.width > 300 || img.height > 300) {
  //         console.log(img.width+ "  " +img.height)
  //         this.selectedFile=null
  //         this.regMsg='100x100 do 300x300'
  //         console.log(this.regMsg)
  //         t=t+1
  //         reject(false)
  //       }
  //       if (!/\.(jpg|jpeg|png)$/i.test(file.name)) {
  //         this.selectedFile=null
  //         this.regMsg="Samo jpg i png formati su dozvoljeni"
  //         console.log(this.regMsg)
  //         reject(false)
  //         t=t+1
  //       }if(t==0)
  //         resolve(true)
  //     }
  //     img.onerror = () => {
  //       console.log("Invalid image file")
  //       this.regMsg="nije fajl slike"
  //       this.selectedFile=null
  //       reject(false)
  //     };
  //   })
  // }
  validateImage(file: File): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (!file) {
        this.regMsg = "No file provided";
        reject(false);
        return;
      }

      if (!/\.(jpg|jpeg|png)$/i.test(file.name)) {
        this.regMsg = "Samo jpg i png formati su dozvoljeni";
        this.selectedFile = null;
        reject(false);
        return;
      }

      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      img.src = objectUrl;
      this.regMsg=""

      img.onload = () => {
        if (img.width < 100 || img.height < 100 || img.width > 300 || img.height > 300) {
          console.log(`Invalid image dimensions: ${img.width}x${img.height}`);
          this.regMsg = 'Dozovljene su slike samo od 100x100 do 300x300';
          this.selectedFile = null;
          URL.revokeObjectURL(objectUrl);
          reject(false);
        } else {
          // console.log(`Valid image dimensions: ${img.width}x${img.height}`);
          URL.revokeObjectURL(objectUrl);
          resolve(true);
        }
      };

      img.onerror = () => {
        console.log("Image load error");
        this.regMsg = "nije fajl slike";
        this.selectedFile = null;
        URL.revokeObjectURL(objectUrl);
        reject(false);
      };
    });
  }
  korZaReg:Korisnik=new Korisnik
  registracija() {

    let fd = new FormData();
    fd.append('korisnik',JSON.stringify(this.korZaReg))
    if(this.selectedFile!=null)
      fd.append('image', this.selectedFile);
    this.testS.registracija(fd).subscribe(res => {
        console.log(res.message);
      });
  }

  kor:Korisnik|null=null


  korPrij:Korisnik=new Korisnik

  prijava(){
    this.testS.login(this.korPrij).subscribe(
      data=>{
        if(data==null)
          alert('Nema')
        this.kor=data;
      }
    )
  }

  testSlika(){
    console.log(this.selectedFile)
  }


}
