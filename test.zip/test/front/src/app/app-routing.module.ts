import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PocetnaComponent } from './pocetna/pocetna.component';
import { PrijavaComponent } from './prijava/prijava.component';
import { RegistracijaComponent } from './registracija/registracija.component';
import { TestComponent } from './test/test.component';
import { PromenaLozinkeComponent } from './promena-lozinke/promena-lozinke.component';
import { PrijavaAdminComponent } from './prijava-admin/prijava-admin.component';
import { GostComponent } from './gost/gost.component';
import { KonobarComponent } from './konobar/konobar.component';
import { AdminComponent } from './admin/admin.component';
import { RestoraniComponent } from './restorani/restorani.component';
import { GostRezComponent } from './gost-rez/gost-rez.component';
import { DostavaComponent } from './dostava/dostava.component';
import { RestoranComponent } from './restoran/restoran.component';
import { KonRezComponent } from './kon-rez/kon-rez.component';
import { KonDosComponent } from './kon-dos/kon-dos.component';
import { StatistikaComponent } from './statistika/statistika.component';

const routes: Routes = [
  {path:'',component:PocetnaComponent},
  {path:'prijava',component:PrijavaComponent},
  {path:'registracija',component:RegistracijaComponent},
  {path:'test',component:TestComponent},
  {path:'promenaLozinke',component:PromenaLozinkeComponent},
  {path:'prijavaAdmin',component:PrijavaAdminComponent},
  {path:'gost',component:GostComponent},
  {path:'konobar',component:KonobarComponent},
  {path:'admin',component:AdminComponent},
  {path:'restorani',component:RestoraniComponent},
  {path:'gostRez',component:GostRezComponent},
  {path:'dostava',component:DostavaComponent},
  {path:'restoran/:naziv',component:RestoranComponent},
  {path:'konRez',component:KonRezComponent},
  {path:'konDos',component:KonDosComponent},
  {path:'statistika',component:StatistikaComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
