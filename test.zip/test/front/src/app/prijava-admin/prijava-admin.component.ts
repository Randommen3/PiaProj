import { Component } from '@angular/core';
import { Korisnik } from '../models/Korisnik';
import { KorisnikService } from '../services/korisnik.service';
import { Router } from '@angular/router';
// import { GreskaReg } from '../models/GreskaReg';

@Component({
  selector: 'app-prijava-admin',
  templateUrl: './prijava-admin.component.html',
  styleUrls: ['./prijava-admin.component.css']
})
export class PrijavaAdminComponent {

  korPrij:Korisnik=new Korisnik
  porukaPrijava:String=''
  constructor(private korS:KorisnikService,private router:Router){}

  // gKorPrij:GreskaReg=new GreskaReg
  prijava(){
    // let bl=false;
    // if(this.korPrij.kor_ime==''){
    //   this.gKorPrij.g_kor_ime="Morate uneti korisnicko ime"
    //   bl=true
    // }
    // if(this.korPrij.lozinka==''){
    //   this.gKorPrij.g_lozinka="Morate uneti lozinku"
    //   bl=true
    // }
    // if(bl)
    //   return
    this.korS.loginAdmin(this.korPrij).subscribe(
      data=>{
        if(data==null){
          this.porukaPrijava='Netacni podaci'
          return
        }
        else{
          console.log('cestitke adminu')
          this.router.navigate(['admin'])
        }
      }
    )
  }

}
