import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../models/Korisnik';
import { KorisnikService } from '../services/korisnik.service';
import { Restoran } from '../models/Restoran';
import { RestoranService } from '../services/restoran.service';

@Component({
  selector: 'app-gost',
  templateUrl: './gost.component.html',
  styleUrls: ['./gost.component.css']
})
export class GostComponent implements OnInit {

  kor:Korisnik=new Korisnik
  novoIme:String=''
  novoPrezime:String=''
  novoImejl:String=''
  novoKontakt:String=''
  novoBrojKartice:String=''
  selectedFile:File|null=null

  constructor(private korS:KorisnikService){}

  ngOnInit(): void {
    let k=localStorage.getItem('gost')
    if(k==null)
      return
    this.kor=JSON.parse(k)
    this.novoIme=this.kor.ime
    this.novoPrezime=this.kor.prezime
    this.novoImejl=this.kor.imejl
    this.novoKontakt=this.kor.kontakt
    this.novoBrojKartice=this.kor.brojKartice
    console.log(k)
    // throw new Error('Method not implemented.');
  }
infoMsg:String=''
  azurirajInfo(){
    this.infoMsg=''
    if(this.novoIme==this.kor.ime
  &&    this.novoPrezime==this.kor.prezime
    &&this.novoImejl==this.kor.imejl
    &&this.novoKontakt==this.kor.kontakt
    &&this.novoBrojKartice==this.kor.brojKartice){
      this.infoMsg='Podaci su nepromenjeni'
      return
    }
    if(!this.imejlValidator()){
      this.infoMsg='Imejl nije u dobrom formatu'
      return
    }
    if(!this.kontaktValidator()){
      this.infoMsg='kontakt nije u dobrom formatu'
      return
    }
    if(!this.kkValidator()){
      this.infoMsg='broj kreditne nije u dobrom formatu'
      return
    }
    let be=false;
    this.korS.sviKor().subscribe(
      data=>{
        if(data){
          data.forEach(
            k=>{
              if(k.imejl==this.novoImejl && k.kor_ime!=this.kor.kor_ime){
                console.log(k.imejl+"  "+k.kor_ime)
                be=true
              }
            }
          )
          if(be){
            this.infoMsg='Nije moguce promeniti na ovaj mejl'
            return
          }
          this.korS.azurirajInfo(this.kor.kor_ime,this.novoIme,this.novoPrezime,this.novoImejl,this.novoKontakt,this.novoBrojKartice).subscribe(
            data1=>{
              if(data1.message=='ok'){
                this.infoMsg='Podaci su azurirani'
                // this.novoIme=this.kor.ime
                // this.novoPrezime=this.kor.prezime
                // this.novoImejl=this.kor.imejl
                // this.novoKontakt=this.kor.kontakt
                // this.novoBrojKartice=this.kor.brojKartice
              }
            }
          )
        }
      }
    )
    // console.log('proslo')

  }

  imejlValidator(): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(this.novoImejl as string);
  }

  kontaktValidator(): boolean {
    const contactPattern = /^\d{3}[-\/]\d{7}$/;
    return contactPattern.test(this.novoKontakt as string);
  }

  kkValidator(): boolean {
    const creditCardPattern = /^\d{4}-\d{4}-\d{4}-\d{4}$/;
    return creditCardPattern.test(this.novoBrojKartice as string);
  }

  onFileSelected(event:any) {
    this.selectedFile=<File>event.target.files[0]
    if(this.selectedFile==null)
      return
    this.validateImage(this.selectedFile).then(
      isValid=>{
        if(isValid)
          console.log(" validna")
      }
    ).catch(error => {
      if(error==false){
        this.selectedFile=null
      }
      console.log(error);
    });
  }
  regMsg:String=''
  validateImage(file: File): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (!file) {
        this.regMsg = "No file provided";
        reject(false);
        return;
      }

      if (!/\.(jpg|jpeg|png)$/i.test(file.name)) {
        this.regMsg = "Samo jpg i png formati su dozvoljeni";
        this.selectedFile = null;
        reject(false);
        return;
      }

      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      img.src = objectUrl;
      this.regMsg=""

      img.onload = () => {
        if (img.width < 100 || img.height < 100 || img.width > 300 || img.height > 300) {
          console.log(`Invalid image dimensions: ${img.width}x${img.height}`);
          this.regMsg = 'Dozovljene su slike samo od 100x100 do 300x300';
          this.selectedFile = null;
          URL.revokeObjectURL(objectUrl);
          reject(false);
        } else {
          console.log(`Valid image dimensions: ${img.width}x${img.height}`);
          URL.revokeObjectURL(objectUrl);
          resolve(true);
        }
      };

      img.onerror = () => {
        console.log("Image load error");
        this.regMsg = "nije fajl slike";
        this.selectedFile = null;
        URL.revokeObjectURL(objectUrl);
        reject(false);
      };
    });
  }

  azurirajSlika(){
    if(!this.selectedFile){
      console.log('nema sl')
    }
  }






}
