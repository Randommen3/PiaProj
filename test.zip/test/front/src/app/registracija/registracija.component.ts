import { Component } from '@angular/core';
import { Korisnik } from '../models/Korisnik';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GreskaReg } from '../models/GreskaReg';
import { KorisnikService } from '../services/korisnik.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registracija',
  templateUrl: './registracija.component.html',
  styleUrls: ['./registracija.component.css']
})
export class RegistracijaComponent {


  constructor(private korS:KorisnikService,private router:Router) {
  }

  // registerForm: FormGroup;
  // constructor(private fb: FormBuilder, private testS:TestService) {
  //   this.registerForm = this.fb.group({
  //     password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(10), this.passwordValidator]],
  //     email: ['', [Validators.required, Validators.email]],
  //     contact: ['', [Validators.required, this.contactValidator]],
  //     creditCard: ['', [Validators.required, this.creditCardValidator]]
  //   });
  // }

  // passwordValidator(control: AbstractControl): { [key: string]: boolean } | null {
  //   const value = control.value;
  //   if (!value) return null;

  //   const passwordPattern = /^(?=[A-Za-z])(?=.*[A-Z])(?=.*[a-z]{3,})(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,10}$/;
  //   return passwordPattern.test(value) ? null : { invalidPassword: true };
  // }

  // contactValidator(control: AbstractControl): { [key: string]: boolean } | null {
  //   const value = control.value;
  //   if (!value) return null;

  //   const contactPattern = /^\d{3}[-\/]\d{7}$/;
  //   return contactPattern.test(value) ? null : { invalidContact: true };
  // }

  // creditCardValidator(control: AbstractControl): { [key: string]: boolean } | null {
  //   const value = control.value;
  //   if (!value) return null;

  //   const creditCardPattern = /^\d{4}-\d{4}-\d{4}-\d{4}$/;
  //   return creditCardPattern.test(value) ? null : { invalidCreditCard: true };
  // }

  korZaReg:Korisnik=new Korisnik
  gZaReg:GreskaReg=new GreskaReg
  private selectedFile: File | null = null;
  regMsg:String=''


  onFileSelected(event:any) {
    this.selectedFile=<File>event.target.files[0]
    if(this.selectedFile==null)
      return
    this.validateImage(this.selectedFile).then(
      isValid=>{
        if(isValid)
          console.log(" validna")
      }
    ).catch(error => {
      if(error==false){
        this.selectedFile=null
      }
      console.log(error);
    });
  }

  validateImage(file: File): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (!file) {
        this.regMsg = "No file provided";
        reject(false);
        return;
      }

      if (!/\.(jpg|jpeg|png)$/i.test(file.name)) {
        this.regMsg = "Samo jpg i png formati su dozvoljeni";
        this.selectedFile = null;
        reject(false);
        return;
      }

      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      img.src = objectUrl;
      this.regMsg=""

      img.onload = () => {
        if (img.width < 100 || img.height < 100 || img.width > 300 || img.height > 300) {
          console.log(`Invalid image dimensions: ${img.width}x${img.height}`);
          this.regMsg = 'Dozovljene su slike samo od 100x100 do 300x300';
          this.selectedFile = null;
          URL.revokeObjectURL(objectUrl);
          reject(false);
        } else {
          console.log(`Valid image dimensions: ${img.width}x${img.height}`);
          URL.revokeObjectURL(objectUrl);
          resolve(true);
        }
      };

      img.onerror = () => {
        console.log("Image load error");
        this.regMsg = "nije fajl slike";
        this.selectedFile = null;
        URL.revokeObjectURL(objectUrl);
        reject(false);
      };
    });
  }

  registracija() {
    let br=false;
    this.gZaReg=new GreskaReg
    console.log(this.korZaReg)
    if(this.korZaReg.kor_ime==""){
      this.gZaReg.g_kor_ime="Korisicko ime je obavezno"
      br=true;
    }
    if(this.korZaReg.lozinka==""){
      this.gZaReg.g_lozinka="Lozinka je obavezna"
      br=true;
    }
    else{
      if(!this.lozinkaValidator()){
        br=true;
        this.gZaReg.g_lozinka="Lozinka nije u dobrom formatu"
      }
    }
    console.log(this.gZaReg.g_lozinka)
    if(this.korZaReg.ime==""){
      this.gZaReg.g_ime="Ime je obavezno"
      br=true;
    }
    if(this.korZaReg.prezime==""){
      this.gZaReg.g_prezime="Prezime je obavezno"
      br=true;
    }
    if(this.korZaReg.pol==""){
      this.gZaReg.g_pol="Pol je obavezno izabrati"
      br=true;
    }
    if(this.korZaReg.adresa==""){
      this.gZaReg.g_adresa="Adresa je obavezna"
      br=true;
    }

    if(this.korZaReg.imejl==""){
      this.gZaReg.g_imejl="Imejl je obavezan"
      br=true;
    }
    else{
      if(!this.imejlValidator()){
        br=true;
        this.gZaReg.g_imejl="Imejl nije u dobrom formatu"
      }
    }

    if(this.korZaReg.kontakt==""){
      this.gZaReg.g_kontakt="Kontakt je obavezan"
      br=true;
    }
    else{
      if(!this.kontaktValidator()){
        br=true;
        this.gZaReg.g_kontakt="Kontakt nije u dobrom formatu"
      }
    }

    if(this.korZaReg.brojKartice==""){
      this.gZaReg.g_brojKartice="Broj kartice je obavezan"
      br=true;
    }
    else{
      if(!this.kkValidator()){
        br=true;
        this.gZaReg.g_brojKartice="Kontakt nije u dobrom formatu"
      }
    }

    if(br){
      console.log('ajmo opet unos')
      return
    }

    this.korS.sviKor().subscribe(
      sviKor=>{
        sviKor.forEach(
          k=>{
            if(k.kor_ime==this.korZaReg.kor_ime){
              this.gZaReg.g_kor_ime="Korisnicko ime je vec zauzeto"
              br=true
            }
            if(k.imejl==this.korZaReg.imejl){
              this.gZaReg.g_imejl="Taj email je vec u upotrebi"
              br=true
            }
          }
        )
        if(br){
          console.log('not so fast champ')
          return
        }
        console.log('mozda ga i ubacimo')
        let fd = new FormData();
        fd.append('korisnik',JSON.stringify(this.korZaReg))
        if(this.selectedFile!=null)
          fd.append('image', this.selectedFile);
        this.korS.registracija(fd).subscribe(res => {
            console.log(res.message);
            if(res.message=='ok'){
              alert('Zahtev za registraciju poslat')
              this.router.navigate([''])
            }
          });
      }
    )



    //
  }
  lozinkaValidator(): boolean {
    const passwordPattern = /^(?=[A-Za-z])(?=.*[A-Z])(?=.*[a-z]{3,})(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,10}$/;
    console.log(passwordPattern.test(this.korZaReg.lozinka as string))
    return passwordPattern.test(this.korZaReg.lozinka as string);
  }

  imejlValidator(): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(this.korZaReg.imejl as string);
  }

  kontaktValidator(): boolean {
    const contactPattern = /^\d{3}[-\/]\d{7}$/;
    return contactPattern.test(this.korZaReg.kontakt as string);
  }

  kkValidator(): boolean {
    const creditCardPattern = /^\d{4}-\d{4}-\d{4}-\d{4}$/;
    return creditCardPattern.test(this.korZaReg.brojKartice as string);
  }





  testSlika(){
    console.log(this.selectedFile)
  }
}
