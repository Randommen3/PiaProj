export class Rezervacija{
        kor_ime:String=''
        restoran:String=''
        datum:Date|null=null
        oslobadjanje:Date|null=null
        brOsoba:Number=0
        brStolova:Number=0
        dodatniZahtevi:String=''
        pojavio:Number=0
        ocenio:Boolean=false
        produzio:Boolean=false
        konobar:String=''
        prihvacen:Number=0
        otkazao:Boolean=false
        adresaR:String=''
        komentarOtkaza:String=''
}
