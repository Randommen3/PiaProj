import { Jelo } from "./Restoran"

export class Dostava{
  kor_ime:String=''
  restoran:String=''
  jela:Jelo[]=[]
  stanje:Number=0
  procena:String=''
  vremeOdluke:Date=new Date()
}

