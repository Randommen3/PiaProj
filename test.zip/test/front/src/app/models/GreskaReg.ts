export class GreskaReg{
  g_kor_ime:String=''
  g_lozinka:String=''
  g_ime:String=''
  g_prezime:String=''
  g_pol:String=''
  g_adresa:String=''
  g_kontakt:String=''
  g_pitanje:String=''
  g_odgovor:String=''
  g_brojKartice:String=''
  g_imejl:String=''


  // constructor(kor_ime: string, lozinka: string, slika: string) {
  //   this.kor_ime = kor_ime;
  //   this.lozinka = lozinka;
  //   this.slika = slika;
  // }
}
