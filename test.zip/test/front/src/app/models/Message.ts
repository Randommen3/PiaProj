export class Message{
  message:String=''
}
