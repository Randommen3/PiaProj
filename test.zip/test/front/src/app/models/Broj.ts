export class Broj{
  broj:Number=0
}
