export class Korisnik{
        kor_ime:String=''
        lozinka:String=''
        tip:String=''
        ime:String=''
        prezime:String=''
        pol:String=''
        adresa:String=''
        kontakt:String=''
        pitanje:String=''
        odgovor:String=''
        slika:String=''
        brojKartice:String=''
        imejl:String=''
        blokiran:Number=0
        deaktiviran:Number=0
        odobren:Number=0
        radiU:String=''

        // constructor(kor_ime: string, lozinka: string, slika: string) {
        //   this.kor_ime = kor_ime;
        //   this.lozinka = lozinka;
        //   this.slika = slika;
        // }
}
