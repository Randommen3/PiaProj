export class Jelo{
  naziv:String=''
  slika:String=''
  opis:String=''
  cena:Number|undefined
  kolicina:Number|undefined
  sastojci: String[]=[]
}

export class Komentar{
  korisnik:String=''
  tekst:String=''
  ocena:Number=1
  datum:Date=new Date
}


export class Restoran{
  naziv:String=''
  adresa:String=''
  tip:String=''
  opis:String=''
  brStolova:Number=0
  osobaPoStolu:Number=0
  radnoVremeOd:String=''
  unosOd:String=''
  radnoVremeDo:String=''
  unosDo:String=''
  telefon:String=''
  komentari:Komentar[]=[]
  jela:Jelo[]=[]
}
