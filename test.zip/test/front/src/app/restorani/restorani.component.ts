import { Component, OnInit } from '@angular/core';
import { Restoran } from '../models/Restoran';
import { RestoranService } from '../services/restoran.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-restorani',
  templateUrl: './restorani.component.html',
  styleUrls: ['./restorani.component.css']
})
export class RestoraniComponent implements OnInit {

  constructor(private resS:RestoranService,private router:Router){}

  restorani:Restoran[]=[]

  ngOnInit(): void {

    this.resS.dohvatiSveRestorane().subscribe(
      data=>this.restorani=data
    )
  }



  srednjaOcenaRest(r:Restoran):number{
    let zbir=0
    let delilac=0
    r.komentari.forEach(k=>{
      zbir=zbir+(k.ocena as number)
      delilac++
    })
    if(delilac==0)
      return zbir
    else{
      return zbir/delilac
    }
  }

  sortNaziv:Number=1
  sortTip:Number=1
  sortAdresa:Number=1
  nazivFilter:String=''
  tipFilter:String=''
  adresaFilter:String=''

  filtrirajRestorane(){
    this.resS.dohvatiFiltrovaneRestorane(this.nazivFilter ,this.tipFilter,this.adresaFilter).subscribe(
      data=>{
        this.restorani=data
      }
    )
  }

  sortByNaziv() {
    this.restorani.sort((a, b) => {
      if (a.naziv < b.naziv) {
        return (this.sortNaziv as number)*(-1);
      }
      if (a.naziv > b.naziv) {
        return (this.sortNaziv as number);
      }
      return 0;
    });
    this.sortNaziv=(this.sortNaziv as number)*(-1);
  }

  sortByAdresa() {
    this.restorani.sort((a, b) => {
      if (a.adresa < b.adresa) {
        return (this.sortAdresa as number)*(-1);
      }
      if (a.adresa > b.adresa) {
        return (this.sortAdresa as number);
      }
      return 0;
    });
    this.sortAdresa=(this.sortAdresa as number)*(-1);
  }
  sortByTip() {
    this.restorani.sort((a, b) => {
      if (a.tip < b.tip) {
        return (this.sortTip as number)*(-1);
      }
      if (a.tip > b.tip) {
        return (this.sortTip as number);
      }
      return 0;
    });
    this.sortTip=(this.sortTip as number)*(-1);
  }

  predjiNaRestoran(r:String){
    this.router.navigate(['/restoran', encodeURIComponent(r as string)]);
  }
}
