import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PrijavaComponent } from './prijava/prijava.component';
import { RegistracijaComponent } from './registracija/registracija.component';
import { PocetnaComponent } from './pocetna/pocetna.component';
import { TestComponent } from './test/test.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PromenaLozinkeComponent } from './promena-lozinke/promena-lozinke.component';
import { PrijavaAdminComponent } from './prijava-admin/prijava-admin.component';
import { GostComponent } from './gost/gost.component';
import { KonobarComponent } from './konobar/konobar.component';
import { AdminComponent } from './admin/admin.component';
import { MeniGostComponent } from './meni/meni-gost/meni-gost.component';
import { MeniKonobarComponent } from './meni/meni-konobar/meni-konobar.component';
import { RestoraniComponent } from './restorani/restorani.component';
import { GostRezComponent } from './gost-rez/gost-rez.component';
import { DostavaComponent } from './dostava/dostava.component';
import { RestoranComponent } from './restoran/restoran.component';
import { StarratingComponent } from './starrating/starrating.component';
import { KonRezComponent } from './kon-rez/kon-rez.component';
import { KonDosComponent } from './kon-dos/kon-dos.component';
import { StatistikaComponent } from './statistika/statistika.component';

@NgModule({
  declarations: [
    AppComponent,
    PrijavaComponent,
    RegistracijaComponent,
    PocetnaComponent,
    TestComponent,
    PromenaLozinkeComponent,
    PrijavaAdminComponent,
    GostComponent,
    KonobarComponent,
    AdminComponent,
    MeniGostComponent,
    MeniKonobarComponent,
    RestoraniComponent,
    GostRezComponent,
    DostavaComponent,
    RestoranComponent,
    StarratingComponent,
    KonRezComponent,
    KonDosComponent,
    StatistikaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
