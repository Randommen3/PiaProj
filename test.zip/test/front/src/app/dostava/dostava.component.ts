import { Component, OnInit } from '@angular/core';
import { DostavaService } from '../services/dostava.service';
import { Dostava } from '../models/Dostava';

@Component({
  selector: 'app-dostava',
  templateUrl: './dostava.component.html',
  styleUrls: ['./dostava.component.css']
})
export class DostavaComponent implements OnInit{

  constructor(private dosS:DostavaService){}
  aktDost:Dostava[]=[]
  gostKor:String=''
  ngOnInit(): void {
    let gost=JSON.parse(localStorage.getItem('gost')??"")
    if(!gost){
      alert('Nije prepoznat korisnik, ulogujte se opet')
      return
    }
    console.log(gost.kor_ime)
    this.gostKor=gost.kor_ime

    this.dosS.dohvatiAktuelneDostave(this.gostKor).subscribe(
      data=>{
        this.aktDost=data
        console.log(data)
        console.log('ok?')
      }
    )
  }

}
