import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GostRezComponent } from './gost-rez.component';

describe('GostRezComponent', () => {
  let component: GostRezComponent;
  let fixture: ComponentFixture<GostRezComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GostRezComponent]
    });
    fixture = TestBed.createComponent(GostRezComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
