import { Component, OnInit } from '@angular/core';
import { RezervacijaService } from '../services/rezervacija.service';
import { Rezervacija } from '../models/Rezervacija';
import { RestoranService } from '../services/restoran.service';

@Component({
  selector: 'app-gost-rez',
  templateUrl: './gost-rez.component.html',
  styleUrls: ['./gost-rez.component.css']
})
export class GostRezComponent implements OnInit{

  constructor(private rezS:RezervacijaService,private resS:RestoranService){}
  ngOnInit(): void {
    let gost=JSON.parse(localStorage.getItem('gost')??"")
    if(!gost){
      alert('Nije prepoznat korisnik, ulogujte se opet')
      return
    }
    console.log(gost.kor_ime)


    this.rezS.aktuelneRezervacijeZaKorisnika(gost.kor_ime).subscribe(
      data=>{
        this.aktuelneRez=data
        this.aktuelneRez.forEach(r=>{
          this.resS.dohvatiRestoran(r.restoran).subscribe(
            res=>{
              r.adresaR=res.adresa
              console.log(r.datum)
              console.log(new Date(r.datum??""))
            }
          )
        })
      }
    )
    this.rezS.istekleRezervacijeZaKorisnika(gost.kor_ime).subscribe(
      data=>{
        this.istekleRez=data
      }
    )
    // throw new Error('Method not implemented.');
  }

  prikaziOtkazivanje(r:Rezervacija){
    const date = new Date(r.datum??"");

    const fortyFiveMinutesAgo = new Date(date.getTime() - 45 * 60000); // 45 minutes in milliseconds

    const currentTime = new Date();

    if (currentTime > fortyFiveMinutesAgo) {
      console.log('Vece od 45');
      return false;
    } else {
      console.log('Manje od 45');
      return true
    }
  }

  otkaziRez(r:Rezervacija){
    console.log("Pokusaj otkaza")
    this.rezS.otkaziRezervaciju(r.kor_ime,r.restoran,new Date(r.datum||"")).subscribe(
      data=>{
        if(data.message=='ok'){
          console.log('ok?')
          r.otkazao=true
        }
      }
    )
  }

  aktuelneRez:Rezervacija[]=[]
  istekleRez:Rezervacija[]=[]
}
