import { Component, OnInit } from '@angular/core';
import { KorisnikService } from '../services/korisnik.service';
import { Korisnik } from '../models/Korisnik';

@Component({
  selector: 'app-konobar',
  templateUrl: './konobar.component.html',
  styleUrls: ['./konobar.component.css']
})
export class KonobarComponent implements OnInit{

  kor:Korisnik=new Korisnik
  novoIme:String=''
  novoPrezime:String=''
  novoImejl:String=''
  novoKontakt:String=''
  selectedFile:File|null=null



  constructor(private korS:KorisnikService){}
  ngOnInit(): void {
    let k=localStorage.getItem('konobar')
    if(k==null)
      return
    this.kor=JSON.parse(k)
    this.novoIme=this.kor.ime
    this.novoPrezime=this.kor.prezime
    this.novoImejl=this.kor.imejl
    this.novoKontakt=this.kor.kontakt
    console.log(k)
  }
  infoMsg:String=''
  azurirajInfo(){
    this.infoMsg=''
    if(this.novoIme==this.kor.ime
  &&    this.novoPrezime==this.kor.prezime
    &&this.novoImejl==this.kor.imejl
    &&this.novoKontakt==this.kor.kontakt){
      this.infoMsg='Podaci su nepromenjeni'
      return
    }
    if(!this.imejlValidator()){
      this.infoMsg='Imejl nije u dobrom formatu'
      return
    }
    if(!this.kontaktValidator()){
      this.infoMsg='kontakt nije u dobrom formatu'
      return
    }
    let be=false;
    this.korS.sviKor().subscribe(
      data=>{
        if(data){
          data.forEach(
            k=>{
              if(k.imejl==this.novoImejl && k.kor_ime!=this.kor.kor_ime){
                console.log(k.imejl+"  "+k.kor_ime)
                be=true
              }
            }
          )
          if(be){
            this.infoMsg='Nije moguce promeniti na ovaj mejl'
            return
          }
          this.korS.azurirajInfo2(this.kor.kor_ime,this.novoIme,this.novoPrezime,this.novoImejl,this.novoKontakt).subscribe(
            data1=>{
              if(data1.message=='ok'){
                this.infoMsg='Podaci su azurirani'
                // this.novoIme=this.kor.ime
                // this.novoPrezime=this.kor.prezime
                // this.novoImejl=this.kor.imejl
                // this.novoKontakt=this.kor.kontakt
                // this.novoBrojKartice=this.kor.brojKartice
              }
            }
          )
        }
      }
    )
    // console.log('proslo')

  }


  imejlValidator(): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(this.novoImejl as string);
  }

  kontaktValidator(): boolean {
    const contactPattern = /^\d{3}[-\/]\d{7}$/;
    return contactPattern.test(this.novoKontakt as string);
  }


  onFileSelected(event:any) {
    this.selectedFile=<File>event.target.files[0]
    if(this.selectedFile==null)
      return
    this.validateImage(this.selectedFile).then(
      isValid=>{
        if(isValid)
          console.log(" validna")
      }
    ).catch(error => {
      if(error==false){
        this.selectedFile=null
      }
      console.log(error);
    });
  }
  regMsg:String=''
  validateImage(file: File): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (!file) {
        this.regMsg = "No file provided";
        reject(false);
        return;
      }

      if (!/\.(jpg|jpeg|png)$/i.test(file.name)) {
        this.regMsg = "Samo jpg i png formati su dozvoljeni";
        this.selectedFile = null;
        reject(false);
        return;
      }

      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      img.src = objectUrl;
      this.regMsg=""

      img.onload = () => {
        if (img.width < 100 || img.height < 100 || img.width > 300 || img.height > 300) {
          console.log(`Invalid image dimensions: ${img.width}x${img.height}`);
          this.regMsg = 'Dozovljene su slike samo od 100x100 do 300x300';
          this.selectedFile = null;
          URL.revokeObjectURL(objectUrl);
          reject(false);
        } else {
          console.log(`Valid image dimensions: ${img.width}x${img.height}`);
          URL.revokeObjectURL(objectUrl);
          resolve(true);
        }
      };

      img.onerror = () => {
        console.log("Image load error");
        this.regMsg = "nije fajl slike";
        this.selectedFile = null;
        URL.revokeObjectURL(objectUrl);
        reject(false);
      };
    });
  }

  azurirajSlika(){
    if(!this.selectedFile){
      console.log('nema sl')
      return
    }
    let fd = new FormData();
    fd.append('image', this.selectedFile);
    fd.append('kor_ime', this.selectedFile);


    this.korS.azurirajSliku(fd).subscribe(
      data=>{
        if(data.message=='')
          alert('azurirano')
      }
    )
  }

}
