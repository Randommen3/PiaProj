import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KonDosComponent } from './kon-dos.component';

describe('KonDosComponent', () => {
  let component: KonDosComponent;
  let fixture: ComponentFixture<KonDosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KonDosComponent]
    });
    fixture = TestBed.createComponent(KonDosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
