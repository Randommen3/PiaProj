import { Component } from '@angular/core';

@Component({
  selector: 'app-kon-dos',
  templateUrl: './kon-dos.component.html',
  styleUrls: ['./kon-dos.component.css']
})
export class KonDosComponent {

}
