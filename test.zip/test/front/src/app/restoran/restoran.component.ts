import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { KorisnikService } from '../services/korisnik.service';
import { Korisnik } from '../models/Korisnik';
import { RestoranService } from '../services/restoran.service';
import { Jelo, Restoran } from '../models/Restoran';
import { Rezervacija } from '../models/Rezervacija';
import { RezervacijaService } from '../services/rezervacija.service';
import { DostavaService } from '../services/dostava.service';
import { Dostava } from '../models/Dostava';

@Component({
  selector: 'app-restoran',
  templateUrl: './restoran.component.html',
  styleUrls: ['./restoran.component.css']
})
export class RestoranComponent implements OnInit{

  constructor(
    private route: ActivatedRoute,
    private resS: RestoranService,
    private rezS:RezervacijaService,
    private dosS:DostavaService
  ) {}

  naziv:String=''
  restoran:Restoran=new Restoran

  ngOnInit(): void {
    this.naziv = decodeURIComponent(this.route.snapshot.paramMap.get('naziv') as string) ;
    console.log(this.naziv)
    // this.route.params.subscribe(params => {
    //   this.naziv = params['naziv'];
    //   this.resS.dohvatiRestoran(this.naziv).subscribe(data => {
    //     this.restoran=data
    //     console.log(this.restoran)
    //   });
    // });

    this.resS.dohvatiRestoran(this.naziv).subscribe(data => {
      this.restoran=data
      console.log(this.restoran)
    });


//     На истој страници са детаљима о ресторану, гост може да направи резервацију стола.
// Први начин резервације је кроз форму где уноси датум и време (кроз Date & Time Picker),
// број особа за који се врши резервација и кратким описом (textarea) корисник може унети
// неке додатне захтеве. Извршити валидацију унете резервације и исписати госту пригодну
// Универзитет у Београду Електротехнички факултет
// Катедра за рачунарску технику и информатику
// 3
// и детаљну поруку (ако ресторан не ради тог дана, или нема слободног стола у том
// периоду за тај број особа).
  }

  novaRez:Rezervacija=new Rezervacija
  msgRezer:String=''

  convertTimeStringToMinutes(timeString: string): number {
    console.log("vr "+timeString)
    const [hours, minutes] = timeString.split(':').map(Number);
    console.log("h:"+hours)
    console.log("m:"+minutes)
    return hours * 60 + minutes;
  }

  convertDateToMinutes(date: Date): number {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    return hours * 60 + minutes;
  }

  rezervisi(){
    console.log("sad: "+new Date())
    if(this.novaRez.datum==null){
      this.msgRezer='Unesite vreme rezervacije'
      return
    }
    if(new Date(this.novaRez.datum)<new Date()){

      this.msgRezer='vreme rezervacije mora biti u buducnosti'
      return
    }
    if(!this.restoran.radnoVremeOd || !this.restoran.radnoVremeDo ){
      console.log('ne moze da se proverava radno vreme')
    }else{
      const radnoVremeOdMinuti = this.convertTimeStringToMinutes(this.restoran.radnoVremeOd as string);
      const radnoVremeDoMinuti = this.convertTimeStringToMinutes(this.restoran.radnoVremeDo as string);
      const rezervacijaMinuti = this.convertDateToMinutes(new Date(this.novaRez.datum));
      console.log(radnoVremeOdMinuti)
      console.log(radnoVremeDoMinuti)
      console.log(rezervacijaMinuti)

      if(radnoVremeOdMinuti<=rezervacijaMinuti && rezervacijaMinuti +180 <= radnoVremeDoMinuti){
        console.log("okej?")
      }else{
        console.log('nije okej')
        return
      }
    }


    if(this.novaRez.brOsoba as number<1){
      this.msgRezer='broj osoba mora biti 1 ili vise'
      return
    }
    console.log(this.novaRez.datum)
    console.log(new Date(this.novaRez.datum))
    // kor_ime:String=''
    // restoran:String=''
    // datum:Date|null=null
    // oslobadjanje:Date|null=null
    // brOsoba:Number=0
    // brStolova:Number=0
    // dodatniZahtevi:String=''
    // pojavio:Number=0
    // ocenio:Boolean=false
    // produzio:Boolean=false
    // konobar:String=''
    // prihvacen:Number=0
    let gost=JSON.parse(localStorage.getItem('gost')??"")
    if(!gost){
      this.msgRezer='Nije prepoznat korisnik, ulogujte se opet'
      return
    }
    if(gost.blokiran>=3){
      this.msgRezer='Korisnik je blokiran za rezervacije'
      return
    }
    else{
      console.log('moze rezers')
    }

    this.novaRez.kor_ime=gost.kor_ime
    this.novaRez.restoran=this.restoran.naziv
    this.novaRez.brStolova=Math.ceil((this.novaRez.brOsoba as number)/(this.restoran.osobaPoStolu as number))

    this.rezS.dodajRez(this.novaRez,this.restoran.brStolova).subscribe(
      data=>{
        if(data.message=='ok'){
          alert(data.message)
        }
        else{}
      }
    )
  }

  jelovnik:Boolean=false;
  dostava:Boolean=false;
  korpa:Jelo[]=[]

  vidiJelovnik(){
    this.jelovnik=true
  }

  vidiDostavu(){
    this.dostava=true
  }

  dodajKorpi(j:Jelo){
    if(!j.kolicina)
      return
    if(j.kolicina as number<0)
      return
    for(let i=0;i<this.korpa.length;i++){
      if(j.naziv==this.korpa[i].naziv){
        if (j.kolicina !== undefined && j.kolicina !== null) {
          this.korpa[i].kolicina = ((this.korpa[i].kolicina ?? 0) as number) + ((j.kolicina ?? 0) as number);
          console.log(this.korpa)
          return
        }
      }
    }
    let novJ:Jelo={
      naziv:j.naziv,
      slika:"",
      opis:"",
      sastojci:[],
      cena:j.cena,
      kolicina:j.kolicina
    }
    this.korpa.push(novJ)
    console.log(this.korpa)
  }
  izbaciIzKorpe(jel:Jelo){
    console.log(this.korpa)
    this.korpa = this.korpa.filter(j => j.naziv !== jel.naziv);
    console.log(this.korpa)

  }

  smanjiZaJedan(j:Jelo){
    if(j.kolicina as number<1){
      this.izbaciIzKorpe(j)
    }
    else{
      j.kolicina=j.kolicina as number -1
    }
  }

  uvecajZaJedan(j:Jelo){
    j.kolicina=j.kolicina as number+1
  }
msgDostava:String=''
  naruci(){
    let d=new Dostava
    d.jela=this.korpa
    // prihvacen:Number=0
    let gost=JSON.parse(localStorage.getItem('gost')??"")
    if(!gost){
      this.msgDostava='Nije prepoznat korisnik, ulogujte se opet'
      return
    }
    d.restoran=this.restoran.naziv
    d.kor_ime=gost.kor_ime
    this.dosS.dodajDostavu(d).subscribe(
      data=>{
        console.log(data)
      }
    )
  }



}
