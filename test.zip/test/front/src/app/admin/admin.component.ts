import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../models/Korisnik';
import { KorisnikService } from '../services/korisnik.service';
import { Restoran } from '../models/Restoran';
import { RestoranService } from '../services/restoran.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent  implements OnInit{
  gosti:Korisnik[]=[]
  konobari:Korisnik[]=[]
  restorani:Restoran[]=[]
  // k:String|null=null

  // test(){
  //   if(this.k==undefined)
  //     console.log('picka izdefinisana')
  // }

  constructor(private korS:KorisnikService, private resS:RestoranService,private router:Router){
  }

  odjava(){
    // localStorage.clear()
    this.router.navigate([''])
  }
  ngOnInit(): void {
  this.korS.sviGosti().subscribe(
      data=>{
        this.gosti=data
      }
    )
    this.korS.sviKonobari().subscribe(
      data=>{
        this.konobari=data
        console.log(data)
      }
    )

    this.resS.dohvatiSveRestorane().subscribe(
      data=>{
        this.restorani=data
        this.restorani.forEach(
          r=>{r.unosOd=r.radnoVremeOd
            r.unosDo=r.unosDo
          })
        console.log(this.restorani)
      }
    )

    // this.test()
    // throw new Error('Method not implemented.');
  }

  aktiviraj(k:Korisnik){
    this.korS.aktivirajKorisnika(k.kor_ime).subscribe(
      data=>{
        if(data.message=='ok'){
          k.deaktiviran=0
        }
      }
    )
  }
  deaktiviraj(k:Korisnik){
    this.korS.deaktivirajKorisnika(k.kor_ime).subscribe(
      data=>{
        if(data.message=='ok'){
          k.deaktiviran=1
        }
      }
    )
  }
  odobri(k:Korisnik){
    this.korS.odobriKorisnika(k.kor_ime).subscribe(
      data=>{
        if(data.message=='ok'){
          k.odobren=1
        }
      }
    )
  }
  odbij(k:Korisnik){
    this.korS.odbijKorisnika(k.kor_ime).subscribe(
      data=>{
        if(data.message=='ok'){
          k.odobren=2
        }
      }
    )
  }

  dodajRadneSate(r:Restoran){
    console.log(r.unosOd, r.unosDo)
    this.resS.dodajRadneSate(r.naziv,r.unosOd,r.unosDo).subscribe(
      data=>{
        if(data.message=='ok'){
          alert('dodati radni sati')
          r.radnoVremeOd=r.unosOd
          r.radnoVremeDo=r.unosDo
        }
      }
    )
  }

  kontaktValidator(s:String): boolean {
    const contactPattern = /^\d{3}[-\/]\d{7}$/;
    return contactPattern.test(s as string);
  }

  novRes:Restoran=new Restoran
  msgRes:String=''
  prikaziNoviRes:boolean=false

  prikaziNoviResFormu(){
    this.prikaziNoviRes=true
  }

  dodajRestoran(){
    if(!this.novRes.naziv || !this.novRes.adresa || !this.novRes.tip || !this.novRes.opis || !this.novRes.telefon || !this.novRes.brStolova || !this.novRes.osobaPoStolu){

     this.msgRes='Popunite sve podatke za restoran pre dodavanja'
     return
    }
    if(!this.kontaktValidator(this.novRes.telefon)){
      this.msgRes='Unesite telefon u odgovarajucem formatu'
      return
    }
    if(this.novRes.brStolova as number<1 || this.novRes.osobaPoStolu as number <1){
      this.msgRes='Niste dobro uneli podatke za stolove'
      return
    }

    this.resS.dohvatiRestoran(this.novRes.naziv).subscribe(
      data2=>{
        if(data2){
          this.msgRes='ime tog restorana je vec zauzeto'
          return
        }

        this.resS.dodajRestoran(this.novRes).subscribe(
          data=>{
            if(data.message=='ok'){
              alert('Dodat')
              this.prikaziNoviRes=false
              this.novRes=new Restoran

              this.resS.dohvatiSveRestorane().subscribe(
                data=>{
                  this.restorani=data
                  this.restorani.forEach(
                    r=>{r.unosOd=r.radnoVremeOd
                      r.unosDo=r.unosDo
                    })
                  console.log(this.restorani)
                }
              )
            }
          }
        )

      }
    )



  }


  novKon:Korisnik=new Korisnik
  msgKon:String=''
  prikaziNoviKon:boolean=false


  prikaziNoviKonFormu(){
    this.prikaziNoviKon=true
  }

  imejlValidator(): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(this.novKon.imejl as string);
  }



  dodajKonobara(){
    if(!this.novKon.kor_ime || !this.novKon.lozinka || !this.novKon.ime  || !this.novKon.prezime || !this.novKon.pol || !this.novKon.adresa || !this.novKon.kontakt || !this.novKon.imejl || !this.novKon.radiU){
      this.msgKon='morate uneti sve podatke'
      return
    }

    if(!this.kontaktValidator(this.novKon.kontakt)){
      this.msgKon='morate uneti kontakt u opisanom patternu'
      return
    }

    if(!this.imejlValidator()){
      this.msgKon='morate uneti dobar mejl'
      return
    }

    let mozeIme=true
    this.korS.sviKor().subscribe(
      data3=>{
        for(let i=0;i<data3.length;i++){
          if(data3[i].kor_ime==this.novKon.kor_ime){
            this.msgKon='Korisnicko ime je zauzeto'
            return
          }
        }
        for(let i=0;i<data3.length;i++){
          if(data3[i].imejl==this.novKon.imejl){
            this.msgKon='Korisnicko ime je zauzeto'
            return
          }
        }

        this.korS.dodajKonobara(this.novKon).subscribe(
          data2=>{
            console.log("Konobar dodat")
            console.log(data2)
            this.prikaziNoviKon=false
            this.novKon=new Korisnik
            this.korS.sviKonobari().subscribe(
              data=>{
                this.konobari=data
              }
            )
          }
        )

      }
    )



  }




}
