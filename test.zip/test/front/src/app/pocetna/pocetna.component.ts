import { Component, OnInit } from '@angular/core';
import { RestoranService } from '../services/restoran.service';
import { Restoran } from '../models/Restoran';
import { KorisnikService } from '../services/korisnik.service';

@Component({
  selector: 'app-pocetna',
  templateUrl: './pocetna.component.html',
  styleUrls: ['./pocetna.component.css']
})
export class PocetnaComponent implements OnInit {

  constructor(private resS:RestoranService,private korS:KorisnikService){}

  restorani:Restoran[]=[]
  brRest:Number=0
  brGost:Number=0

  ngOnInit(): void {
    this.resS.dohvatiSveRestorane().subscribe(
      data=> this.restorani=data
    )
    this.resS.dohvatiBrojRestorana().subscribe(
      data=>{this.brRest=data}
    )
    this.korS.dohvatiBrojGostiju().subscribe(
      data=>{this.brGost=data}
    )

    // throw new Error('Method not implemented.');
  }
  sortNaziv:Number=1
  sortTip:Number=1
  sortAdresa:Number=1
  nazivFilter:String=''
  tipFilter:String=''
  adresaFilter:String=''

  filtrirajRestorane(){
    this.resS.dohvatiFiltrovaneRestorane(this.nazivFilter ,this.tipFilter,this.adresaFilter).subscribe(
      data=>{
        this.restorani=data
      }
    )
  }

  sortByNaziv() {
    this.restorani.sort((a, b) => {
      if (a.naziv < b.naziv) {
        return (this.sortNaziv as number)*(-1);
      }
      if (a.naziv > b.naziv) {
        return (this.sortNaziv as number);
      }
      return 0;
    });
    this.sortNaziv=(this.sortNaziv as number)*(-1);
  }

  sortByAdresa() {
    this.restorani.sort((a, b) => {
      if (a.adresa < b.adresa) {
        return (this.sortAdresa as number)*(-1);
      }
      if (a.adresa > b.adresa) {
        return (this.sortAdresa as number);
      }
      return 0;
    });
    this.sortAdresa=(this.sortAdresa as number)*(-1);
  }
  sortByTip() {
    this.restorani.sort((a, b) => {
      if (a.tip < b.tip) {
        return (this.sortTip as number)*(-1);
      }
      if (a.tip > b.tip) {
        return (this.sortTip as number);
      }
      return 0;
    });
    this.sortTip=(this.sortTip as number)*(-1);
  }


}
