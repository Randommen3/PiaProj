import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Message } from '../models/Message';
import { Dostava } from '../models/Dostava';

@Injectable({
  providedIn: 'root'
})
export class DostavaService {

  constructor(private http:HttpClient) { }
  dodajDostavu(d:Dostava) {
    return this.http.post<Message>('http://localhost:4000/dostava/dodajDostavu', d);
  }
  dohvatiAktuelneDostave(kor_ime:String) {
    return this.http.post<Dostava[]>('http://localhost:4000/dostava/dohvatiAktuelneDostave',{kor_ime:kor_ime});
  }


}
