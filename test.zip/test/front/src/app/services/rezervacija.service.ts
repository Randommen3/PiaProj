import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Message } from '../models/Message';
import { Rezervacija } from '../models/Rezervacija';

@Injectable({
  providedIn: 'root'
})
export class RezervacijaService {

  constructor(private http:HttpClient) { }

  dodajRez(rez:Rezervacija,maxBrojStolovaRestorana:Number) {
    return this.http.post<Message>('http://localhost:4000/rezervacija/dodajRez',{rez:rez,maxBrojStolovaRestorana:maxBrojStolovaRestorana});
  }

  aktuelneRezervacijeZaKorisnika(kor_ime:String) {
    return this.http.post<Rezervacija[]>('http://localhost:4000/rezervacija/aktuelneRezervacijeZaKorisnika',{kor_ime:kor_ime});
  }
  istekleRezervacijeZaKorisnika(kor_ime:String) {
    return this.http.post<Rezervacija[]>('http://localhost:4000/rezervacija/istekleRezervacijeZaKorisnika',{kor_ime:kor_ime});
  }

  dohvatiNeobradjeneRezervacijeZaRestoran(restoran:String) {
    return this.http.post<Rezervacija[]>('http://localhost:4000/rezervacija/dohvatiNeobradjeneRezervacijeZaRestoran',{restoran:restoran});
  }

  prihvatiRez(r:Rezervacija,konobar:String) {
    return this.http.post<Message>('http://localhost:4000/rezervacija/prihvatiRez',{kor_ime:r.kor_ime,restoran:r.restoran,datum:r.datum,konobar:konobar});
  }

  odbijRez(r:Rezervacija) {
    return this.http.post<Message>('http://localhost:4000/rezervacija/odbijRez',{kor_ime:r.kor_ime,restoran:r.restoran,datum:r.datum,komentarOtkaza:r.komentarOtkaza});
  }

  otkaziRezervaciju(kor_ime:String,restoran:String,datum:Date) {
    return this.http.post<Message>('http://localhost:4000/rezervacija/otkaziRezervaciju',{kor_ime:kor_ime,restoran:restoran,datum:datum});
  }

  rezervacijeKojeOcekujeKonobar(konobar:String) {
    return this.http.post<Rezervacija[]>('http://localhost:4000/rezervacija/rezervacijeKojeOcekujeKonobar',{konobar:konobar});
  }

  gostNijeDosao(kor_ime:String,restoran:String,datum:Date) {
    return this.http.post<Message>('http://localhost:4000/rezervacija/gostNijeDosao',{kor_ime:kor_ime,restoran:restoran,datum:datum});
  }

  gostDosao(kor_ime:String,restoran:String,datum:Date) {
    return this.http.post<Message>('http://localhost:4000/rezervacija/gostDosao',{kor_ime:kor_ime,restoran:restoran,datum:datum});
  }

  produziRez(kor_ime:String,restoran:String,datum:Date) {
    return this.http.post<Message>('http://localhost:4000/rezervacija/produziRez',{kor_ime:kor_ime,restoran:restoran,datum:datum});
  }

  dohvatiTrenutnoUsluzavaneRezervacije(konobar:String) {
    return this.http.post<Rezervacija[]>('http://localhost:4000/rezervacija/dohvatiTrenutnoUsluzavaneRezervacije',{konobar:konobar});
  }




}
