import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Message } from '../models/Message';
import { Korisnik } from '../models/Korisnik';

@Injectable({
  providedIn: 'root'
})
export class KorisnikService {

  constructor(private http:HttpClient) { }

  registracija(fd:FormData){
    return this.http.post<Message>('http://localhost:4000/korisnik/register', fd)
  }

  login(kor:Korisnik) {
    return this.http.post<Korisnik>('http://localhost:4000/korisnik/login', { korisnik:kor });
  }

  loginAdmin(kor:Korisnik) {
    return this.http.post<Korisnik>('http://localhost:4000/korisnik/loginAdmin', { korisnik:kor });
  }

  sviKor() {
    return this.http.get<Korisnik[]>('http://localhost:4000/korisnik/sviKor');
  }

  sviGosti() {
    return this.http.get<Korisnik[]>('http://localhost:4000/korisnik/sviGosti');
  }

  sviKonobari() {
    return this.http.get<Korisnik[]>('http://localhost:4000/korisnik/sviKonobari');
  }

  promenaLozinkeStarom(kor:Korisnik,novaLozinka:string) {
    return this.http.post<Message>('http://localhost:4000/korisnik/promenaLozinkeStarom', { korisnik:kor,novaLozinka:novaLozinka });
  }

  azurirajSliku(fd:FormData){
    return this.http.post<Message>('http://localhost:4000/korisnik/azurirajSliku', fd)
  }

  azurirajInfo(kor_ime:String,ime:String,prezime:String,imejl:String,kontakt:String,brojKartice:String){
    return this.http.post<Message>('http://localhost:4000/korisnik/azurirajInfo', {kor_ime:kor_ime,ime:ime,prezime:prezime,imejl:imejl,kontakt:kontakt,brojKartice:brojKartice})
  }

  azurirajInfo2(kor_ime:String,ime:String,prezime:String,imejl:String,kontakt:String){
    return this.http.post<Message>('http://localhost:4000/korisnik/azurirajInfo2', {kor_ime:kor_ime,ime:ime,prezime:prezime,imejl:imejl,kontakt:kontakt})
  }

  aktivirajKorisnika(kor_ime:String){
    return this.http.post<Message>('http://localhost:4000/korisnik/aktivirajKorisnika',{kor_ime:kor_ime})
  }

  deaktivirajKorisnika(kor_ime:String){
    return this.http.post<Message>('http://localhost:4000/korisnik/deaktivirajKorisnika',{kor_ime:kor_ime})
  }

  odobriKorisnika(kor_ime:String){
    return this.http.post<Message>('http://localhost:4000/korisnik/odobriKorisnika',{kor_ime:kor_ime})
  }

  odbijKorisnika(kor_ime:String){
    return this.http.post<Message>('http://localhost:4000/korisnik/odbijKorisnika',{kor_ime:kor_ime})
  }
  dodajKonobara(k:Korisnik){
    return this.http.post<Message>('http://localhost:4000/korisnik/dodajKonobara',k)
  }
  dohvatiBrojGostiju() {
    return this.http.get<Number>('http://localhost:4000/korisnik/dohvatiBrojGostiju');
  }
  uvecajKorisnikuBlokiran(kor_ime:String){
    return this.http.post<Message>('http://localhost:4000/korisnik/uvecajKorisnikuBlokiran',{kor_ime:kor_ime})
  }













//   sviKor = (req: express.Request, res: express.Response)=>{
//     Korisnik.find({}).then(
//         data=>{
//             res.json(data)
//         }
//     ).catch((err) => {
//         console.log(err);
//         res.status(500).json({ message: 'Error catching users' });
//     });
// }
}
