import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Restoran } from '../models/Restoran';
import { Broj } from '../models/Broj';
import { Message } from '../models/Message';

@Injectable({
  providedIn: 'root'
})
export class RestoranService {

  constructor(private http:HttpClient) { }

  dohvatiSveRestorane() {
    return this.http.get<Restoran[]>('http://localhost:4000/restoran/dohvatiSveRestorane');
  }

  dohvatiBrojRestorana() {
    return this.http.get<Number>('http://localhost:4000/restoran/dohvatiBrojRestorana');
  }

  dodajRadneSate(naziv:String,radnoVremeOd:String,radnoVremeDo:String){
    return this.http.post<Message>('http://localhost:4000/restoran/dodajRadneSate',{naziv:naziv,radnoVremeOd:radnoVremeOd,radnoVremeDo:radnoVremeDo});
  }

  dohvatiRestoran(naziv:String) {
    return this.http.post<Restoran>('http://localhost:4000/restoran/dohvatiRestoran',{naziv:naziv});
  }

  dodajRestoran(r:Restoran) {
    return this.http.post<Message>('http://localhost:4000/restoran/dodajRestoran',{restoran:r});
  }


  dohvatiFiltrovaneRestorane(naziv:String,tip:String,adresa:String) {
    return this.http.post<Restoran[]>('http://localhost:4000/restoran/dohvatiFiltrovaneRestorane',{ naziv:naziv, tip:tip, adresa:adresa });
  }




}
