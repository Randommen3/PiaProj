import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Message } from '../models/Message';
import { Korisnik } from '../models/Korisnik';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor(private http:HttpClient) { }

  registracija(fd:FormData){
    return this.http.post<Message>('http://localhost:4000/test/register', fd)
  }

  login(kor:Korisnik) {
    return this.http.post<Korisnik>('http://localhost:4000/test/login', { korisnik:kor });
  }



}
