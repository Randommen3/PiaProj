import { Component } from '@angular/core';
import { KorisnikService } from '../services/korisnik.service';
import { Korisnik } from '../models/Korisnik';

@Component({
  selector: 'app-promena-lozinke',
  templateUrl: './promena-lozinke.component.html',
  styleUrls: ['./promena-lozinke.component.css']
})
export class PromenaLozinkeComponent {

  constructor(private korS:KorisnikService){}

  kor:Korisnik=new Korisnik
  novaLozinka:string=''
  ponovljenaLozinka:string=''
  msgPromena:String=''


  lozinkaValidator(loz:string): boolean {
    const passwordPattern = /^(?=[A-Za-z])(?=.*[A-Z])(?=.*[a-z]{3,})(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,10}$/;
    console.log(passwordPattern.test(loz))
    return passwordPattern.test(loz);
  }

  promenaLozinkeStarom(){
    // let bc=false
    if(this.kor.kor_ime==''){
      this.msgPromena='Morate uneti korisnicko ime'
      return
    }
    if(this.kor.lozinka==''){
      this.msgPromena='Morate uneti staru lozinku'
      return
    }
    if(this.novaLozinka==''){
      this.msgPromena='Morate uneti novu lozinku'
      return
    }
    if(this.ponovljenaLozinka==''){
      this.msgPromena='Morate ponoviti novu lozinku'
      return
    }
    if(this.novaLozinka!=this.ponovljenaLozinka){
      this.msgPromena='Ponovljena nova lozinka nije kao nova lozinka'
      return
    }
    if(!this.lozinkaValidator(this.novaLozinka)){
      this.msgPromena='Lozinka nije u ispravnom formatu'
      return
    }

    this.korS.promenaLozinkeStarom(this.kor,this.novaLozinka).subscribe(
      data=>{
        if(data.message=='ok'){
          this.msgPromena='Lozinka je uspesno promenjena'
        }
      }
    )
  }

  msgPromenaSigPitanje:String=''
}
