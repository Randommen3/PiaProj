import { Component } from '@angular/core';
import { Korisnik } from '../models/Korisnik';
import { KorisnikService } from '../services/korisnik.service';
import { GreskaReg } from '../models/GreskaReg';
import { Router } from '@angular/router';

@Component({
  selector: 'app-prijava',
  templateUrl: './prijava.component.html',
  styleUrls: ['./prijava.component.css']
})
export class PrijavaComponent {

  korPrij:Korisnik=new Korisnik
  gKorPrij:GreskaReg=new GreskaReg

  constructor(private korS:KorisnikService,private router:Router){}

  porukaPrijava:String=''
  kor:Korisnik=new Korisnik
  prijava(){
    this.porukaPrijava=''
    let bl=false;
    if(this.korPrij.kor_ime==''){
      this.gKorPrij.g_kor_ime="Morate uneti korisnicko ime"
      bl=true
    }
    if(this.korPrij.lozinka==''){
      this.gKorPrij.g_lozinka="Morate uneti lozinku"
      bl=true
    }
    if(bl)
      return
    this.korS.login(this.korPrij).subscribe(
      data=>{
        if(data==null){
          this.porukaPrijava='Netacni podaci'
          return
        }
        else{
          if(data.odobren==0){
            this.porukaPrijava="Vas nalog jos nije odobren, pokusajte kasnije"
            return
          }
          if(data.odobren==2){
            this.porukaPrijava="Vas nalog za reg nije odobren"
            return
          }
          if(data.deaktiviran==1){
            this.porukaPrijava="Vas nalog je deaktiviran, ne mozete se ulogovati"
            return
          }
          // this.kor=data;


          localStorage.setItem(data.tip as string,JSON.stringify(data))

          this.router.navigate([data.tip])

        }
      }
    )
  }



}
