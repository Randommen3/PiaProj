import { Component, Input, OnInit } from '@angular/core';




@Component({
  selector: 'app-starrating',
  templateUrl: './starrating.component.html',
  styleUrls: ['./starrating.component.css']
})
export class StarratingComponent {
  @Input() rating: number|undefined;
  starWidth: string='';

  ngOnInit() {
    this.starWidth = `${(this.rating as number / 5) * 100}%`;
  }
}
