import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../models/Korisnik';
import { RezervacijaService } from '../services/rezervacija.service';
import { Rezervacija } from '../models/Rezervacija';
import { KorisnikService } from '../services/korisnik.service';

@Component({
  selector: 'app-kon-rez',
  templateUrl: './kon-rez.component.html',
  styleUrls: ['./kon-rez.component.css']
})
export class KonRezComponent implements OnInit{

  constructor(private rezS:RezervacijaService,private korS:KorisnikService){}
  ngOnInit(): void {
    let k=localStorage.getItem('konobar')
    if(k==null)
      return
    this.kono=JSON.parse(k)
    console.log(this.kono)
    this.updateRez()

  }

  updateRez(){

    this.rezS.dohvatiNeobradjeneRezervacijeZaRestoran(this.kono.radiU).subscribe(
      data=>{
        data.sort((a,b)=>{
          if(new Date(a.datum??"")<new Date(b.datum??"")){
            return -1
          }
          else{
            return 1
          }
        })
        this.neobRez=data
        console.log(this.neobRez)
      }
    )

    this.rezS.rezervacijeKojeOcekujeKonobar(this.kono.kor_ime).subscribe(
      data=>{
        data.sort((a,b)=>{
          if(new Date(a.datum??"")<new Date(b.datum??"")){
            return -1
          }
          else{
            return 1
          }
        })
        this.ocekRez=data
        console.log(data)
      }
    )

    this.rezS.dohvatiTrenutnoUsluzavaneRezervacije(this.kono.kor_ime).subscribe(
      data=>{
        data.sort((a,b)=>{
          if(new Date(a.datum??"")<new Date(b.datum??"")){
            return -1
          }
          else{
            return 1
          }
        })
        this.trRez=data
        console.log(this.trRez)
      }
    )

  }

  kono:Korisnik=new Korisnik
  neobRez:Rezervacija[]=[]
  ocekRez:Rezervacija[]=[]
  trRez:Rezervacija[]=[]

  prihvatiRez(r:Rezervacija){
    this.rezS.prihvatiRez(r,this.kono.kor_ime).subscribe(
      data=>{
        if(data.message=='ok'){
          console.log('prihvacena')
          this.updateRez()
        }
      }
    )
  }

  odbijRez(r:Rezervacija){
    if(r.komentarOtkaza==''){
      alert('Komentar je obavezan ako se odbija')
      return
    }

    this.rezS.odbijRez(r).subscribe(
      data=>{
        if(data.message=='ok'){
          console.log(`odbijena `)
          this.updateRez()
        }
      }
    )
  }

  gostDosao(r:Rezervacija){

    const reservationTime = new Date(r.datum ?? "");
    const currentTime = new Date();
    reservationTime.setMinutes(reservationTime.getMinutes() + 30);
    if (reservationTime > currentTime) {
      alert('Mora da prodje 30 min pre nego sto potvrdite')
        return;
      }



    this.rezS.gostDosao(r.kor_ime,r.restoran,new Date(r.datum??"")).subscribe(
      data=>{
        if(data.message=='ok')
        this.updateRez()
      }
    )
  }

  gostNijeDosao(r:Rezervacija){


    const reservationTime = new Date(r.datum ?? "");
    const currentTime = new Date();
    reservationTime.setMinutes(reservationTime.getMinutes() + 30);
    if (reservationTime > currentTime) {
      alert('Mora da prodje 30 min pre nego sto potvrdite')
        return;
      }
    this.rezS.gostNijeDosao(r.kor_ime,r.restoran,new Date(r.datum??"")).subscribe(
      data=>{
        if(data.message=='ok')
        console.log('stavljeno da nije dosao')
        this.korS.uvecajKorisnikuBlokiran(r.kor_ime).subscribe(
          data2=>{
            if(data2.message=='ok'){
              console.log('uvecan blokiran')
            }
          }
        )
        this.updateRez()
      }
    )
  }

  produziRez(r:Rezervacija){
    this.rezS.produziRez(r.kor_ime,r.restoran,new Date(r.datum??"")).subscribe(
      data=>{
        if(data.message=='ok'){
          let k = new Date (r.oslobadjanje??"")
          k.setHours(k.getHours()+1)
          r.oslobadjanje=k
        }
      }
    )
  }

}
