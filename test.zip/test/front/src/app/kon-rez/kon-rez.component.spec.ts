import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KonRezComponent } from './kon-rez.component';

describe('KonRezComponent', () => {
  let component: KonRezComponent;
  let fixture: ComponentFixture<KonRezComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KonRezComponent]
    });
    fixture = TestBed.createComponent(KonRezComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
